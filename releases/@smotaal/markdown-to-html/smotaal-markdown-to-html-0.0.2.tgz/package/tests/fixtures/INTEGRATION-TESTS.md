# Integration Tests

> **What is an integration test?** A test that checks MULTIPLE classes working together. Some dependencies may be real, some mocked.

## Summary

| Metric           | Value                                  |
| ---------------- | -------------------------------------- |
| Total Files      | 7                                      |
| Total Tests      | 158                                    |
| Average per File | 23 tests                               |
| Environment      | Browser (5 files) or Node.js (2 files) |

## Difference from Unit Tests

| Aspect       | Unit Test  | Integration Test |
| ------------ | ---------- | ---------------- |
| Scope        | One class  | Multiple classes |
| Dependencies | All mocked | Some real        |
| Speed        | Fast       | Slower           |
| Isolation    | Complete   | Partial          |

## Test Files

### 1. signaling-coordinator.spec.ts (37 tests)

**Tests**: SignalingCoordinator with multiple channel types

**Purpose**: Verify unified signaling across primary and relay channels.

| Test Group         | What It Verifies               |
| ------------------ | ------------------------------ |
| Constructor        | Initializes with channels      |
| Signal Routing     | Messages go to correct channel |
| Event Handling     | Events from both channels      |
| Relay Messages     | P2P relay works                |
| Connection Metrics | Track active connections       |
| Error Recovery     | Handle channel failures        |

**Real Dependencies**:

- SignalingCoordinator
- PeerConnections collection
- Multiple SignalingChannel implementations

**Mocked Dependencies**:

- SignalingChannel objects (using vi.fn())
- WebSocket connections

**Guarantees Made**:

- Primary channel used for server signaling
- Relay channel used for P2P signaling
- Events forwarded correctly from all channels
- Connection metrics are accurate

**Limitations**:

- Mock channels don't test real WebSocket
- Timing of relay not tested
- Error recovery limited to mocked scenarios

**Related**: FEAT-251224-11

---

### 2. multi-peer-controller.spec.ts (31 tests)

**Tests**: MultiPeerController with Peers and PeerConnections

**Purpose**: Verify orchestration of multi-peer mesh networking.

| Test Group           | What It Verifies                                |
| -------------------- | ----------------------------------------------- |
| Initial State        | Controller starts disconnected                  |
| State Machine        | Transitions: disconnected → joining → connected |
| Peer Tracking        | Peers added/removed correctly                   |
| Message Broadcasting | Messages sent to all connections                |
| Room Management      | Join/leave room operations                      |
| Error Handling       | Invalid operations rejected                     |

**Real Dependencies**:

- Peers collection
- PeerConnections collection
- Peer objects

**Mocked Dependencies**:

- Signaling channel
- RTCPeerConnection (no actual WebRTC)

**Guarantees Made**:

- State transitions follow expected flow
- Peers are tracked across state changes
- Broadcasting reaches all connections

**Limitations**:

- No real WebRTC negotiation
- No real signaling server
- Timing of broadcasts not verified

---

### 3. peer-list-exchange.spec.ts (24 tests)

**Tests**: Peer discovery protocol (Phase 2)

**Purpose**: Verify peer list exchange between connected peers.

| Test Group                         | What It Verifies              |
| ---------------------------------- | ----------------------------- |
| PeerConnection peer-list messages  | List format and sending       |
| MultiPeerController peer discovery | New peers discovered via list |
| Strategy isolation                 | Mesh vs server peers separate |
| Peer list filtering                | Only relevant peers shared    |

**Protocol Flow**:

```text
1. Peer A connects to Peer B
2. Peer A sends peer-list to Peer B
3. Peer B discovers Peer C exists (from list)
4. Peer B initiates connection to Peer C
```

**Real Dependencies**:

- Peers collection
- MultiPeerController
- PeerConnection (partial)

**Mocked Dependencies**:

- DataChannel
- Signaling channel

**Guarantees Made**:

- Peer lists are exchanged after connection
- New peers trigger discovery events
- Strategy filtering works

**Limitations**:

- No real DataChannel messages
- Discovery timing not verified
- Network partitions not tested

**Related**: FIX-251226-07

---

### 4. signaling-server-integration.spec.ts (29 tests)

**Tests**: Real WebSocket signaling server

**Purpose**: Verify full signaling protocol with actual server.

| Test Group         | What It Verifies              |
| ------------------ | ----------------------------- |
| Room join/leave    | Server tracks room membership |
| Peer discovery     | Peers see each other in room  |
| Targeted signaling | Messages reach intended peer  |
| Heartbeat          | Connection stays alive        |
| Broadcast messages | All room members receive      |

**Environment**: Node.js (`@vitest-environment node`)

**Real Dependencies**:

- WebSocket connections
- Signaling server (started for tests)
- Protocol messages

**Mocked Dependencies**:

- None (full integration)

**Guarantees Made**:

- Server correctly routes messages
- Room isolation works
- Heartbeat keeps connections alive

**Limitations**:

- Localhost only (no real network)
- Single server instance
- No load testing
- No error injection

---

### 5. signaling-cloudflare.spec.ts (11 tests)

**Tests**: Cloudflare Durable Object implementation

**Purpose**: Verify Cloudflare-specific signaling handler.

| Test Group                 | What It Verifies            |
| -------------------------- | --------------------------- |
| Worker handler URL routing | Correct paths handled       |
| Error responses            | Invalid requests rejected   |
| Room isolation             | Separate rooms are isolated |
| WebSocketPair behavior     | Cloudflare WebSocket works  |

**Environment**: Node.js (`@vitest-environment node`)

**Real Dependencies**:

- Durable Object handler code

**Mocked Dependencies**:

- WebSocketPair (Cloudflare-specific)
- DurableObjectState
- Request/Response objects

**Guarantees Made**:

- URL routing matches expected patterns
- Errors return proper HTTP status
- Room state is isolated

**Limitations**:

- Not running in actual Cloudflare environment
- Mock WebSocketPair may differ from real
- No actual persistence tested
- No alarm/scheduling tested

**Deployment Checklist** (from file comments):

- [ ] Worker builds successfully
- [ ] Durable Object bindings configured
- [ ] WebSocket upgrade works
- [ ] Room isolation verified

---

### 6. debug-logger.spec.ts (17 tests)

**Tests**: Debug logging infrastructure

**Purpose**: Verify console interception and SharedWorker logging.

| Test Group     | What It Verifies                        |
| -------------- | --------------------------------------- |
| Console Proxy  | console.log/info/warn/error intercepted |
| Error Handlers | Global errors captured                  |
| DebugLogger    | Messages stored and retrievable         |
| SharedWorker   | Cross-tab log aggregation               |

**Real Dependencies**:

- Browser console object
- BroadcastChannel
- SharedWorker (browser)

**Mocked Dependencies**:

- None (tests in real browser)

**Guarantees Made**:

- Console methods are intercepted
- Errors are captured with stack traces
- SharedWorker aggregates from all tabs

**Limitations**:

- SharedWorker may not be available in all browsers
- Log retention limits not tested
- Memory usage not monitored

**Related**: FEAT-251212-03

---

### 7. test-isolation.spec.ts (9 tests)

**Tests**: Test isolation between test files

**Purpose**: Verify tests don't affect each other.

| Test Group                     | What It Verifies                      |
| ------------------------------ | ------------------------------------- |
| Browser State                  | localStorage, sessionStorage, cookies |
| State Modification and Cleanup | Changes are reverted                  |
| Page State                     | Service workers, IndexedDB            |

**What This Tests**:

```text
Test File A modifies localStorage
Test File B runs → should NOT see A's changes
```

**Real Dependencies**:

- All browser storage APIs
- Page lifecycle

**Mocked Dependencies**:

- None

**Guarantees Made**:

- localStorage is cleared between files
- sessionStorage is cleared between files
- Cookies are cleared between files
- Service workers are unregistered

**Limitations**:

- Within same file, tests MAY share state
- Cleanup depends on afterEach hooks
- Race conditions possible

**Important Documentation** (from file):

> Pages are shared within a file but isolated between files. This means tests in the same file may see each other's state if cleanup is incomplete.

---

## Integration Points

### What Gets Integrated

| Test File                            | Components Integrated               |
| ------------------------------------ | ----------------------------------- |
| multi-peer-controller.spec.ts        | Controller + Peers + Connections    |
| peer-list-exchange.spec.ts           | Controller + Protocol + DataChannel |
| signaling-server-integration.spec.ts | Client + Server + WebSocket         |
| signaling-cloudflare.spec.ts         | Handler + DurableObject + WebSocket |
| debug-logger.spec.ts                 | Console + BroadcastChannel + Worker |
| test-isolation.spec.ts               | Storage + Page + Lifecycle          |

### What Remains Mocked

Even in integration tests, some things are typically mocked:

| Component         | Why Mocked                  |
| ----------------- | --------------------------- |
| RTCPeerConnection | Requires real network/media |
| Real network      | Tests run on localhost      |
| Time              | Avoid test duration         |
| Random            | Deterministic results       |

---

## Common Patterns

### Server Integration Pattern

```typescript
// @vitest-environment node
import { WebSocket } from "ws";

let server: SignalingServer;

beforeAll(async () => {
    server = await startSignalingServer();
});

afterAll(async () => {
    await server.close();
});

test("client connects", async () => {
    const client = new WebSocket(server.url);
    await waitForOpen(client);
    expect(client.readyState).toBe(WebSocket.OPEN);
});
```

### Multi-Component Pattern

```typescript
beforeAll(async () => {
    await navigateTo("/peer-to-peer-chat/tests/");
    await page.waitForFunction(() => window.testModulesLoaded);
});

test("components work together", async () => {
    const result = await page.evaluate(() => {
        const { Controller, Peers, Connections } = window.testModules;

        const peers = new Peers();
        const connections = new Connections();
        const controller = new Controller(peers, connections);

        controller.addPeer({ id: "peer-1" });
        return controller.state;
    });

    expect(result).toBe("connected");
});
```

---

## Validation Questions

When reviewing these tests, ask:

1. **Are all integration points tested?** Check that components interact.
2. **Are boundaries clear?** Know what's real vs mocked.
3. **Is cleanup complete?** Connections, servers, state all cleaned.
4. **Are timeouts appropriate?** Network operations need longer timeouts.
5. **Is error propagation tested?** Errors in one component affect others.

---

## False Positive Risks

These tests might pass when code is broken:

| Risk                     | Example                             |
| ------------------------ | ----------------------------------- |
| Mock hides real behavior | Mock signaling succeeds, real fails |
| Order dependency         | Tests pass only in specific order   |
| Timing assumption        | Fast machine passes, slow fails     |
| Incomplete cleanup       | Previous test left working state    |

## False Negative Risks

These tests might fail when code is correct:

| Risk                | Example                         |
| ------------------- | ------------------------------- |
| Resource contention | Port already in use             |
| Network latency     | Localhost has variable latency  |
| Concurrent tests    | Tests interfere with each other |
| External dependency | Service temporarily unavailable |

---

## Debugging Integration Tests

### When a Test Fails

1. **Check logs**: Look at server logs and browser logs
2. **Check timing**: Add delays to rule out race conditions
3. **Check cleanup**: Run test in isolation (`yarn vitest run --testNamePattern="test name"`)
4. **Check dependencies**: Verify all services are running

### Common Issues

| Symptom              | Likely Cause                       |
| -------------------- | ---------------------------------- |
| "Connection refused" | Server not started                 |
| "Timeout"            | Waiting for event that never fires |
| "State mismatch"     | Previous test didn't clean up      |
| "Cannot find module" | Module not loaded in browser       |

<style>
.mermaid svg { display: block; margin-left: auto; margin-right: auto; width: auto; }
@media print { h1, h2, h3, h4, h5, h6 { page-break-after: avoid; break-after: avoid-page; } }
@media print { table, figure, div.no-break { page-break-inside: avoid; break-inside: avoid-page; } }
@media print { p:has(+table, +figure, +div.no-break) { page-break-before: avoid; break-before: avoid; page-break-inside: avoid; break-inside: avoid-page; page-break-after: avoid; break-after: avoid-page; } }
</style>
<script type="module">
  import mermaid from 'https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.esm.min.mjs';
  [...document.querySelectorAll('pre:has(> code:first-child:last-child.lang-mermaid)') ].forEach(pre => { Object.assign(pre, {className: 'mermaid', innerHTML: pre.innerText}) });
  mermaid.initialize({ startOnLoad: true });
</script>
