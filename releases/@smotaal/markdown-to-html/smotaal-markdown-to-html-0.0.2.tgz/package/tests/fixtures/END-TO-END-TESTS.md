# End-to-End Tests

> **What is an end-to-end test?** A test that verifies COMPLETE user workflows in a real browser. Real components, real DOM, real network (where possible).

## Summary

| Metric           | Value                                |
| ---------------- | ------------------------------------ |
| Total Files      | 6                                    |
| Total Tests      | 131                                  |
| Average per File | 22 tests                             |
| Environment      | Real Chromium browser via Playwright |

## Difference from Other Test Types

| Aspect          | Unit Test | Integration Test | E2E Test             |
| --------------- | --------- | ---------------- | -------------------- |
| Scope           | One class | Multiple classes | Full app             |
| Browser         | Optional  | Optional         | Required             |
| Network         | Mocked    | Partial          | Real (when possible) |
| User Simulation | None      | None             | Yes                  |

## Test Files

### 1. demo-flow.spec.ts

**Tests**: Complete user flow for PeerToPeerChatApp

**Purpose**: Verify initiator and receiver role workflows work correctly.

| Test Group          | What It Verifies                                  |
| ------------------- | ------------------------------------------------- |
| Initial Load        | Demo page loads without errors                    |
| Receiver Role       | Opening `?offer=` URL triggers acceptOfferFromUrl |
| Button Interactions | Connection flow logs appear correctly             |
| URL Handling        | Offer parameter cleared after processing          |
| Offer Processing    | Valid offers trigger ICE gathering                |

**User Stories Tested**:

```text
Initiator (Peer A):
1. Opens /peer-to-peer-chat/
2. Enters display name
3. Clicks "Create Offer"
4. Sees step transition: idle → creating-offer → waiting-for-answer

Receiver (Peer B):
1. Opens offer URL (?offer=...)
2. Step shows: creating-answer (NOT idle)
3. Sees generated answer to copy
```

**Testing Approach**:

- Uses console log inspection (closed shadow DOM prevents direct UI access)
- Verifies URL parameter handling
- Tests error handling for invalid offers

**Guarantees Made**:

- Demo page loads without critical errors
- Offer URLs are processed correctly
- Invalid offers don't crash the app

**Limitations**:

- Cannot test internal UI due to closed shadow DOM
- Relies on console logs for verification
- No actual WebRTC connection (mock SDP)

**Related**: FIX-251227-04

---

### 2. multi-peer-app-element.spec.ts

**Tests**: MultiPeerChatAppElement custom element

**Purpose**: Verify element registration, properties, and public API.

| Test Group               | What It Verifies                                  |
| ------------------------ | ------------------------------------------------- |
| Element Registration     | Registers as 'multi-peer-chat-app'                |
| Initial State            | Starts disconnected, connection panel visible     |
| Room UI                  | roomId property, joinRoom/leaveRoom methods       |
| Signaling Server Config  | signalingServerURL property                       |
| Peer List Integration    | peers property returns Peers instance             |
| Connection State         | state, connectedPeerCount, totalPeerCount         |
| Messaging API            | broadcast method exists and works                 |
| Local Peer Identity      | localPeerName property                            |
| Event Support            | statechange, peerjoined, peerleft, message events |
| Signaling Auto-Detection | **SIGNALING_SERVER_PORT** global                  |
| Strategy Toggle UI       | mesh/server radio buttons                         |

**Testing Approach**:

- Creates elements programmatically
- Tests public API surface only
- Cannot inspect shadow DOM (closed)

**Guarantees Made**:

- Element can be created via `document.createElement`
- All public properties are accessible
- Events can be listened to
- Class is frozen (immutable)

**Limitations**:

- Cannot verify internal UI rendering
- Cannot test actual WebSocket connections
- Event firing verification limited

**Related**: FEAT-251224-12

---

### 3. peer-list-element.spec.ts

**Tests**: PeerListElement UI component

**Purpose**: Verify peer list display and interaction.

| Test Group           | What It Verifies                                   |
| -------------------- | -------------------------------------------------- |
| Element Registration | Registers as 'peer-list'                           |
| Shadow DOM Structure | Has closed shadow root                             |
| Peers Property       | Accepts Peers instance, null clears                |
| Empty State          | Shows message when no peers                        |
| Peer Display         | Displays peer names, updates on change             |
| State Indicators     | Shows connected/connecting/discovered/disconnected |
| Peer Count           | Shows total and connected count                    |
| Selection Support    | selectable attribute, peerselect event             |
| Events               | peerclick event                                    |
| Cleanup              | Event listeners removed on disconnect              |

**Testing Approach**:

- Tests via public API and element dimensions
- Uses `getBoundingClientRect()` to verify rendering
- Event listener attachment verified

**Guarantees Made**:

- Peers collection can be set and retrieved
- Element renders with content when peers exist
- Selection state is tracked
- Events are dispatchable

**Limitations**:

- Cannot verify visual appearance
- Cannot verify internal slot content
- Click events may not reach shadow DOM elements

---

### 4. step-elements.spec.ts

**Tests**: StepContainerElement and StepsContainerElement

**Purpose**: Verify step-based UI layout and visibility management.

| Test Group           | What It Verifies                         |
| -------------------- | ---------------------------------------- |
| Element Registration | Both elements registered correctly       |
| Attributes           | step, label, current attribute handling  |
| Shadow DOM           | Closed shadow root                       |
| Slots                | instructions, actions, and default slots |
| Step Visibility      | Only current step is active              |
| Dynamic Children     | Visibility updates when children added   |
| Class Immutability   | Classes are frozen                       |

**Step Visibility Logic**:

```text
<steps-container current="step-2">
  <step-container step="step-1">Hidden</step-container>
  <step-container step="step-2">Visible (has data-active)</step-container>
  <step-container step="step-3">Hidden</step-container>
</steps-container>
```

**Testing Approach**:

- Tests attribute reflection (property ↔ attribute)
- Tests `data-active` attribute on step elements
- Tests dynamic child handling via MutationObserver

**Guarantees Made**:

- Attributes sync with properties
- Only one step can be active at a time
- Dynamically added steps respect current attribute

**Limitations**:

- Cannot verify CSS-based visibility
- Cannot verify slot projection rendering
- MutationObserver timing may vary

**Related**: REFACTOR-251222-04, REFACTOR-251222-05

---

### 5. multi-peer-signaling.spec.ts

**Tests**: WebSocketSignalingChannel class

**Purpose**: Verify room-based multi-peer signaling API.

| Test Group             | What It Verifies                                   |
| ---------------------- | -------------------------------------------------- |
| Initial State          | Creates with URL and roomId, state is disconnected |
| Room Peer Tracking     | roomPeers returns array                            |
| Leave Room             | Clears local peer state, safe when not connected   |
| Close Behavior         | close() calls leaveRoom                            |
| Extended Message Types | Inherits from SignalingChannel                     |
| Message Send API       | send() queues when disconnected, sendTo() exists   |
| Event Listeners        | roompeers, peerjoined, peerleft, error events      |

**Testing Approach**:

- Tests API without actual WebSocket connection
- Verifies state management and error handling
- Tests event listener attachment

**Guarantees Made**:

- Channel can be created without connecting
- leaveRoom is safe to call anytime
- Events can be listened to
- sendTo method exists for targeted messaging

**Limitations**:

- No actual WebSocket connection tested
- No real server interaction
- Event dispatch not verified (only listener attachment)

---

### 6. multi-peer-mesh.spec.ts

**Tests**: Multi-browser mesh networking

**Purpose**: Verify complete E2E flow with real WebRTC connections.

| Test Group                | What It Verifies                      |
| ------------------------- | ------------------------------------- |
| Mesh Calculations         | N peers need N*(N-1)/2 connections    |
| Peer Discovery Simulation | Peers collection state transitions    |
| Connection Tracking       | PeerConnections collection management |
| MultiPeerController Setup | Controller initialization             |
| 2-Peer Mesh (Unit)        | Basic peer and connection tracking    |
| 3-Peer Mesh (Unit)        | Larger mesh connection tracking       |
| E2E Mesh Tests            | Real multi-browser WebRTC             |

**E2E Tests Detail**:

| Test                                      | What It Verifies                    |
| ----------------------------------------- | ----------------------------------- |
| two peers can discover each other         | Signaling server delivers peer info |
| connection established in both directions | WebRTC connection completes         |
| messages reach the other peer             | DataChannel messaging works         |
| three peers form complete mesh            | Full 3-peer mesh connectivity       |
| broadcast from one reaches both others    | Message broadcast works             |
| peer departure notifies remaining peers   | Graceful disconnection handling     |

**Testing Architecture**:

```text
┌──────────────────────────────────────────────────────────────┐
│ Playwright Browser Server (shared)                           │
├──────────────────────────────────────────────────────────────┤
│ Peer A Browser Instance                                      │
│ ├─ Virtual Origin: https://peer-alice.localhost              │
│ └─ page.route() proxies to real Vite server                  │
├──────────────────────────────────────────────────────────────┤
│ Peer B Browser Instance                                      │
│ ├─ Virtual Origin: https://peer-bob.localhost                │
│ └─ page.route() proxies to real Vite server                  │
├──────────────────────────────────────────────────────────────┤
│ Vite Dev/Preview Server                                      │
│ └─ Serves actual app and signaling WebSocket                 │
└──────────────────────────────────────────────────────────────┘
```

**Virtual Origins Approach**:

- Uses `page.route()` to intercept HTTP requests
- Each peer gets a unique `*.localhost` origin
- Enables true cross-origin testing
- WebSocket connections bypass `page.route()` (use real server)

**Why `*.localhost` Domains**:

| Domain Pattern      | Secure Context? | Why?                               |
| ------------------- | --------------- | ---------------------------------- |
| `*.test` HTTP       | No              | Not in browser secure list         |
| `*.localhost` HTTP  | No              | HTTP is never secure               |
| `*.localhost` HTTPS | Yes             | Browsers treat localhost as secure |

`crypto.randomUUID()` (used for peer IDs) requires a secure context.

**Guarantees Made**:

- Peers can discover each other via signaling
- WebRTC connections establish successfully
- Messages are delivered via DataChannel
- Mesh topology forms correctly (N-1 connections per peer)
- Peer departure is handled gracefully

**Limitations**:

- Runs on localhost only (no real network latency)
- WebSocket signaling is real (cannot mock via page.route)
- Timeouts may need adjustment for slow machines
- No ICE candidate relay testing (TURN servers)

**Related**: FEAT-251228-01 (Virtual Origins)

---

## Common Patterns

### Browser Test Pattern

Most E2E tests load modules via the test page:

```typescript
beforeAll(async () => {
    await navigateTo("/peer-to-peer-chat/tests/");
    await waitForModules();
});

test("example", async () => {
    const result = await page.evaluate(() => {
        const { SomeElement } = window.testModules;
        const element = document.createElement("some-element");
        document.body.appendChild(element);
        // Test public API
        return element.someProperty;
    });
    expect(result).toBe(expected);
});
```

### Console Log Verification Pattern

For testing closed shadow DOM elements:

```typescript
function hasLogContaining(...substrings: string[]): boolean {
    return browserLogs.some(log =>
        substrings.every(s => log.includes(s))
    );
}

test("action logs expected message", async () => {
    // Trigger action
    await page.evaluate(() => { /* trigger action */ });

    // Verify via console log
    expect(hasLogContaining("expected", "message")).toBe(true);
});
```

### Multi-Browser Pattern

For testing peer-to-peer scenarios:

```typescript
async function createPeerContext(peerId: string, peerName: string) {
    const peerBrowser = await chromium.connect(wsEndpoint);
    const context = await peerBrowser.newContext({ ignoreHTTPSErrors: true });
    const peerPage = await context.newPage();

    // Set up virtual origin routing
    await peerPage.route(`${virtualOrigin}/**`, async (route) => {
        const realUrl = route.request().url().replace(virtualOrigin, baseURL);
        const response = await context.request.fetch(realUrl);
        await route.fulfill({ /* proxy response */ });
    });

    return { browser: peerBrowser, context, page: peerPage };
}
```

### Event Wait Pattern

For async event-driven testing:

```typescript
async function expectMessage(peer: PeerContext, messageSubstring: string) {
    // Set up listener BEFORE the action that triggers the event
    await peer.page.evaluate(({ substring }) => {
        window.__messagePromise = new Promise((resolve) => {
            const app = document.querySelector("multi-peer-chat-app");
            app.addEventListener("message", (event) => {
                if (event.detail.message.content.includes(substring)) {
                    resolve(true);
                }
            });
        });
    }, { substring: messageSubstring });

    return peer.page.evaluate(() => window.__messagePromise);
}

test("message received", async () => {
    const messagePromise = await expectMessage(peerB, "Hello");
    await sendMessage(peerA, "Hello World");
    expect(await messagePromise).toBe(true);
});
```

---

## Validation Questions

When reviewing these tests, ask:

1. **Is the user flow realistic?** Tests should mimic actual user behavior.
2. **Are race conditions handled?** Async operations need proper waiting.
3. **Is cleanup complete?** Browser contexts, event listeners, connections.
4. **Are timeouts appropriate?** Network operations need longer timeouts.
5. **Can closed shadow DOM be tested?** Use public API, not internal elements.

---

## False Positive Risks

These tests might pass when code is broken:

| Risk                     | Example                                |
| ------------------------ | -------------------------------------- |
| Console log verification | Log message present but feature broken |
| Dimension check only     | Element has size but wrong content     |
| Event listener added     | Listener exists but never fires        |
| Timing luck              | Race condition doesn't manifest        |

## False Negative Risks

These tests might fail when code is correct:

| Risk                | Example                       |
| ------------------- | ----------------------------- |
| Timeout too short   | Network latency exceeds limit |
| Browser state       | Previous test leaked state    |
| Resource contention | Port already in use           |
| Flaky WebRTC        | ICE gathering timing varies   |

---

## Debugging E2E Tests

### When a Test Fails

1. **Run with visible browser**: `VITE_DEBUG_SERVE=1 yarn test`
2. **Check browser logs**: `console.log(browserLogs)`
3. **Add screenshots**: `await page.screenshot({ path: 'debug.png' })`
4. **Increase timeouts**: May be timing issue
5. **Run in isolation**: `yarn vitest run --testNamePattern="test name"`

### Common Issues

| Symptom                            | Likely Cause                     |
| ---------------------------------- | -------------------------------- |
| "Element not found"                | Custom element not registered    |
| "shadowRoot is null"               | Shadow root is closed (expected) |
| "Timeout waiting for function"     | Async operation didn't complete  |
| "crypto.randomUUID not a function" | Not a secure context             |
| "Connection refused"               | Signaling server not started     |

### Virtual Origins Issues

| Symptom                            | Likely Cause                       |
| ---------------------------------- | ---------------------------------- |
| "ERR_SSL_PROTOCOL_ERROR"           | Need ignoreHTTPSErrors: true       |
| "crypto.randomUUID not a function" | Using HTTP instead of HTTPS        |
| WebSocket fails                    | WS connections bypass page.route() |
| CORS errors                        | Virtual origin not properly routed |

---

## Test Timeouts

| Test Type            | Recommended Timeout |
| -------------------- | ------------------- |
| Element registration | 10 seconds          |
| Page navigation      | 15 seconds          |
| Signaling connection | 15 seconds          |
| WebRTC connection    | 30 seconds          |
| Full mesh (3 peers)  | 60 seconds          |

---

## Related Documentation

- [README.md](./README.md) - Test overview
- [UNIT-TESTS.md](./UNIT-TESTS.md) - Unit test details
- [INTEGRATION-TESTS.md](./INTEGRATION-TESTS.md) - Integration test details
- [vitest-global-test-setup.ts](../../../tests/helpers/vitest-global-test-setup.ts) - Test infrastructure

<style>
.mermaid svg { display: block; margin-left: auto; margin-right: auto; width: auto; }
@media print { h1, h2, h3, h4, h5, h6 { page-break-after: avoid; break-after: avoid-page; } }
@media print { table, figure, div.no-break { page-break-inside: avoid; break-inside: avoid-page; } }
@media print { p:has(+table, +figure, +div.no-break) { page-break-before: avoid; break-before: avoid; page-break-inside: avoid; break-inside: avoid-page; page-break-after: avoid; break-after: avoid-page; } }
</style>
<script type="module">
  import mermaid from 'https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.esm.min.mjs';
  [...document.querySelectorAll('pre:has(> code:first-child:last-child.lang-mermaid)') ].forEach(pre => { Object.assign(pre, {className: 'mermaid', innerHTML: pre.innerText}) });
  mermaid.initialize({ startOnLoad: true });
</script>
