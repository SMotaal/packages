# Unit Tests

> **What is a unit test?** A test that checks ONE class or function in isolation. Dependencies are mocked or stubbed.

## Summary

| Metric           | Value                                 |
| ---------------- | ------------------------------------- |
| Total Files      | 8                                     |
| Total Tests      | 187                                   |
| Average per File | 23 tests                              |
| Environment      | Browser (7 files) or Node.js (1 file) |

## Test Files

### 1. signaling.spec.ts (21 tests)

**Tests**: AdhocSignalingChannel class AND Peer class

**Purpose**: Verify offer/answer encoding/decoding and peer ID generation.

| Test Group            | What It Verifies                            |
| --------------------- | ------------------------------------------- |
| encode/decode         | Round-trip encoding preserves data          |
| URL handling          | Encoded signals work in URL parameters      |
| signal handling       | Offers and answers are correctly identified |
| Session ID extraction | Offer IDs are extracted from signals        |
| Peer                  | Peer ID generation, name handling           |

**Dependencies Mocked**: None (pure functions)

**Guarantees Made**:

- Encoded signals decode to identical data
- URL-safe encoding works
- Offer/answer type detection is accurate
- Peer IDs are unique UUIDs

**Limitations**:

- Does not test with real WebRTC objects
- Does not test compression edge cases
- Assumes UTF-8 encoding
- Requires secure context for crypto.randomUUID

**Related Fixes**: FIX-251227-01, FIX-251227-04, FIX-251226-08

---

### 2. peers.spec.ts

**Tests**: Peers collection class

**Purpose**: Verify peer management, state tracking, and strategy isolation.

| Test Group                | What It Verifies               |
| ------------------------- | ------------------------------ |
| Basic Operations          | add, get, remove, has, clear   |
| Connection State Tracking | State changes are tracked      |
| Bulk Operations           | addAll, removeAll              |
| Events                    | Event dispatch on changes      |
| Strategy Support          | Mesh vs server-based isolation |
| Iterator Support          | for...of works correctly       |

**Dependencies Mocked**: Peer objects

**Guarantees Made**:

- Peers are stored by ID
- State changes dispatch events
- Strategies are isolated (mesh peers separate from server peers)

**Limitations**:

- Peer objects are simple mocks
- Does not test concurrent modifications
- Event timing not verified

---

### 3. peer-connections.spec.ts

**Tests**: PeerConnections collection class

**Purpose**: Verify connection management and event forwarding.

| Test Group          | What It Verifies                     |
| ------------------- | ------------------------------------ |
| Basic Operations    | add, get, remove, has                |
| Query Methods       | getByPeerId, getByState              |
| Event Forwarding    | Events from connections bubble up    |
| Cleanup             | dispose removes all connections      |
| All Connected Event | Fires when all reach connected state |

**Dependencies Mocked**: PeerConnection objects

**Guarantees Made**:

- Connections are stored by ID
- Events propagate correctly
- Cleanup disposes all connections

**Limitations**:

- Mock connections don't have real RTCPeerConnection
- State transitions are simulated
- No actual WebRTC negotiation

---

### 4. signaling-server-configuration.spec.ts

**Tests**: SignalingServerConfiguration class

**Purpose**: Verify URL and mode parsing for signaling server config.

| Test Group     | What It Verifies                  |
| -------------- | --------------------------------- |
| MODES constant | Enum values exist                 |
| parse() method | Mode detection from config string |

**Modes Tested**:

| Input                 | Mode       |
| --------------------- | ---------- |
| `undefined`           | default    |
| `"ws://example.com"`  | configured |
| `"wss://example.com"` | configured |
| `"ws://example.com!"` | only       |
| `"-"`                 | disabled   |

**Dependencies Mocked**: None (pure functions)

**Guarantees Made**:

- Mode detection is deterministic
- URL extraction is correct
- Special characters (!, -) are handled

**Limitations**:

- Does not test invalid URLs
- Does not test URL normalization
- No network connectivity checks

**Related**: REFACTOR-251222-01

---

### 5. peer-identity-manager.spec.ts

**Tests**: PeerIdentityManager class

**Purpose**: Verify localStorage-based identity storage.

| Test Group                | What It Verifies             |
| ------------------------- | ---------------------------- |
| constructor               | Initializes with storage key |
| getLocalName/setLocalName | Local peer name storage      |
| getPetName/setPetName     | Pet names for remote peers   |
| identity updates          | Changes persist              |

**Dependencies Mocked**: localStorage (browser environment)

**Guarantees Made**:

- Names persist across page reloads
- Pet names are per-peer
- Empty strings are handled

**Limitations**:

- Requires browser environment
- localStorage may be cleared by user
- No cross-tab synchronization tested

**Related**: REFACTOR-251222-02

---

### 6. session-state-manager.spec.ts

**Tests**: SessionStateManager class

**Purpose**: Verify sessionStorage-based session state.

| Test Group    | What It Verifies           |
| ------------- | -------------------------- |
| isAvailable   | Storage availability check |
| display name  | Session-specific name      |
| signaling URL | Session-specific URL       |
| room ID       | Session-specific room      |
| strategy      | Mesh vs server strategy    |
| pet names     | Session-specific pet names |

**Key Difference from PeerIdentityManager**:

| PeerIdentityManager | SessionStateManager |
| ------------------- | ------------------- |
| Uses localStorage   | Uses sessionStorage |
| Persists forever    | Clears on tab close |
| Shared across tabs  | Isolated per tab    |

**Dependencies Mocked**: sessionStorage (browser environment)

**Guarantees Made**:

- Tab isolation works
- State clears on tab close
- Unavailable storage handled gracefully

**Limitations**:

- Requires browser environment
- Cannot test actual tab isolation in unit tests
- Storage limits not tested

**Related**: FEAT-251224-03

---

### 7. connection-flow-controller.spec.ts

**Tests**: ConnectionFlowController state machine

**Purpose**: Verify WebRTC connection lifecycle states.

| Test Group        | What It Verifies           |
| ----------------- | -------------------------- |
| STATES constant   | All states exist           |
| constructor       | Initial state is idle      |
| state transitions | Valid transitions work     |
| event handling    | Events trigger transitions |

**State Machine**:

```text
idle → creating-offer → waiting-for-answer → connecting → connected
                                                      ↓
                                              disconnected
```

**Dependencies Mocked**: None (pure state machine)

**Guarantees Made**:

- State transitions are deterministic
- Invalid transitions are rejected
- Events map to correct transitions

**Limitations**:

- Does not test actual RTCPeerConnection events
- Timing between states not verified
- Error recovery paths limited

**Related**: REFACTOR-251222-03

---

### 8. signaling-protocol.spec.ts

**Tests**: Protocol exports and validation

**Purpose**: Verify protocol message formats and validators.

| Test Group              | What It Verifies           |
| ----------------------- | -------------------------- |
| MessageTypes            | All message types exist    |
| validateRoomJoinPayload | Payload validation         |
| SignalingRoomState      | Room state management      |
| Message factories       | Message creation functions |

**Environment**: Node.js (`@vitest-environment node`)

**Dependencies Mocked**: None (pure functions)

**Guarantees Made**:

- Message types are constants
- Validation rejects invalid payloads
- Room state tracks correctly

**Limitations**:

- Does not test message serialization
- No network encoding tested
- Protocol version compatibility not tested

---

## Common Patterns

### Module Loading Pattern

Most unit tests load modules via browser:

```typescript
beforeAll(async () => {
    await navigateTo("/peer-to-peer-chat/tests/");
    await page.waitForFunction(() => window.testModulesLoaded);
});

test("example", async () => {
    const result = await page.evaluate(() => {
        const { SomeClass } = window.testModules;
        return new SomeClass().someMethod();
    });
    expect(result).toBe(expected);
});
```

### Pure Node.js Pattern

Some tests run in Node.js:

```typescript
// @vitest-environment node
import { SomeFunction } from "../classes/some-module.js";

test("example", () => {
    expect(SomeFunction("input")).toBe("output");
});
```

---

## Validation Questions

When reviewing these tests, ask:

1. **Is the class truly isolated?** Check imports for hidden dependencies.
2. **Are mocks realistic?** Mock behavior should match real objects.
3. **Are edge cases covered?** Empty, null, undefined, large values.
4. **Are errors tested?** Invalid inputs should throw or return error.
5. **Is state cleaned up?** Tests should not affect each other.

---

## False Positive Risks

These tests might pass when code is broken:

| Risk              | Example                          |
| ----------------- | -------------------------------- |
| Mock too simple   | Mock returns success, real fails |
| Missing edge case | Only happy path tested           |
| Async timing      | Test completes before error      |
| State leakage     | Previous test left good state    |

## False Negative Risks

These tests might fail when code is correct:

| Risk                   | Example                             |
| ---------------------- | ----------------------------------- |
| Brittle assertion      | Exact string match on error message |
| Timing sensitive       | Slow machine triggers timeout       |
| Environment difference | Works in Node, fails in browser     |
| Non-deterministic      | Random IDs differ between runs      |

<style>
.mermaid svg { display: block; margin-left: auto; margin-right: auto; width: auto; }
@media print { h1, h2, h3, h4, h5, h6 { page-break-after: avoid; break-after: avoid-page; } }
@media print { table, figure, div.no-break { page-break-inside: avoid; break-inside: avoid-page; } }
@media print { p:has(+table, +figure, +div.no-break) { page-break-before: avoid; break-before: avoid; page-break-inside: avoid; break-inside: avoid-page; page-break-after: avoid; break-after: avoid-page; } }
</style>
<script type="module">
  import mermaid from 'https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.esm.min.mjs';
  [...document.querySelectorAll('pre:has(> code:first-child:last-child.lang-mermaid)') ].forEach(pre => { Object.assign(pre, {className: 'mermaid', innerHTML: pre.innerText}) });
  mermaid.initialize({ startOnLoad: true });
</script>
