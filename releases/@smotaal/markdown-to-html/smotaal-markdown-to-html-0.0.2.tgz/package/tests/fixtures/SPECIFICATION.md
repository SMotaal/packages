# Peer-to-Peer Chat: Specification & Design Document

> **Version:** 1.0.0  
> **Date:** December 27, 2025  
> **Status:** Prototype Implementation  

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [System Overview](#2-system-overview)
3. [Architecture](#3-architecture)
4. [Core Components](#4-core-components)
5. [Signaling Infrastructure](#5-signaling-infrastructure)
6. [Multi-Peer Mesh Networking](#6-multi-peer-mesh-networking)
7. [Data Flow & Protocols](#7-data-flow--protocols)
8. [UI Components](#8-ui-components)
9. [State Management](#9-state-management)
10. [Debug Infrastructure](#10-debug-infrastructure)
11. [Security Considerations](#11-security-considerations)
12. [API Reference](#12-api-reference)
13. [Deployment](#13-deployment)

## 1. Executive Summary

### 1.1 Purpose

The Peer-to-Peer Chat application is a WebRTC-based real-time communication system that enables direct browser-to-browser messaging without requiring messages to pass through a central server. It supports two modes of operation:

1. **Adhoc Signaling** — Manual out-of-band offer/answer exchange via URLs (serverless)
2. **Server-Based Signaling** — WebSocket-based room discovery and automatic peer connection

### 1.2 Key Features

| Feature                      | Description                                                                               |
| ---------------------------- | ----------------------------------------------------------------------------------------- |
| **Direct P2P Communication** | Messages flow directly between browsers via WebRTC DataChannels                           |
| **Multi-Peer Mesh Topology** | Full mesh network supporting N peers with N-1 connections each                            |
| **Dual Signaling Modes**     | Adhoc (URL-based) and server-mediated signaling                                           |
| **Relay Signaling**          | BFS-based message relay through mesh for peers not directly connected to signaling server |
| **Peer Discovery**           | Automatic peer list exchange for mesh expansion                                           |
| **Identity Management**      | Persistent display names and peer-assigned "pet-names"                                    |
| **Dark Mode Support**        | Full CSS custom property theming with `light-dark()`                                      |
| **Cross-Tab Debugging**      | SharedWorker-based log aggregation across browser tabs                                    |

### 1.3 Technology Stack

| Layer          | Technology                                               |
| -------------- | -------------------------------------------------------- |
| Transport      | WebRTC (RTCPeerConnection, RTCDataChannel)               |
| Signaling      | WebSocket (custom protocol) / URL-based adhoc            |
| UI Framework   | Web Components (Custom Elements v1)                      |
| Build System   | Vite                                                     |
| Server Runtime | Node.js 24+ (built-in modules only) / Cloudflare Workers |
| Type Safety    | JSDoc with TypeScript checking                           |

### 1.4 Key Design Decisions

| Decision                             | Rationale                                                                      |
| ------------------------------------ | ------------------------------------------------------------------------------ |
| **Classes separate from Elements**   | UI-agnostic logic in `classes/` enables CLI usage and unit testing without DOM |
| **Closed Shadow DOM**                | Style isolation prevents CSS conflicts; explicit slot-based composition        |
| **sessionStorage over localStorage** | Tab-specific state prevents cross-tab conflicts during multi-peer testing      |
| **BFS relay routing**                | Optimal path discovery with loop detection; no centralized topology knowledge  |
| **ICE candidate queuing**            | Solves timing issues when candidates arrive before remote description is set   |
| **Bundled adhoc signals**            | Single URL contains SDP with ICE candidates inline (no separate array)         |

## 2. System Overview

### 2.1 High-Level Architecture

```mermaid
graph TB
    subgraph "Browser Tab (Peer A)"
        UI[MultiPeerChatAppElement<br/>UI Layer]
        MPC[MultiPeerController<br/>Orchestration]
        SC[SignalingCoordinator<br/>Route Manager]
        PC[PeerConnections<br/>RTCPeerConn×N]
        P[Peers<br/>Identity Store]
        CH[WebSocketSignalingChannel<br/>AdhocChannel]
        UI --> MPC
        MPC --> SC
        MPC --> PC
        MPC --> P
        SC --> CH
    end

    subgraph "Signaling Server (Optional)"
        RM[Room Management]
        PR[Peer Registry]
        MR[Message Routing]
    end

    CH <--> |WebSocket| RM
    PC <--> |WebRTC DataChannel| OtherPeers[Other Peers]
```

### 2.2 Connection Topology

**Mesh Network:** Each peer maintains direct WebRTC connections to all other peers in the room.

```mermaid
block
  columns 3
  A["Peer A"] space B["Peer B"] 
  space:3
  C["Peer C"] space D["Peer D"]
  
  A<-->B
  C<-->D
  A<-->C
  B<-->D
  A<-->D
  B<-->C

  classDef node width:6em,height:6em,
  class A,B,C,D node;
```

**Connection Formula:** N peers = N(N-1)/2 total connections (e.g., 4 peers = 6 connections)

## 3. Architecture

### 3.1 Layer Diagram

```mermaid
graph TB
    subgraph PRESENTATION["PRESENTATION LAYER"]
        direction TB
        MPCA[MultiPeerChatAppElement]
        PLE[PeerListElement]
        CCE[ChatContainerElement]
    end

    subgraph CONTROLLER["CONTROLLER LAYER"]
        direction TB
        MPC2[MultiPeerController]
        SC2[SignalingCoordinator]
        CFC[ConnectionFlowController]
    end

    subgraph MODEL["MODEL LAYER"]
       direction TB
        subgraph MODEL2[" "]
          Peer2[Peer Identity]
          PConn[PeerConnection WebRTC]
          PIM[PeerIdentityManager]
        end
        subgraph MODEL1[" "]
          Peers2[Peers Collection]
          PCs[PeerConnections Collection]
          SSM[SessionStateManager]
        end
        class MODEL1,MODEL2 noFrame;
    end

    subgraph TRANSPORT["TRANSPORT LAYER"]
       direction TB
        SCH[SignalingChannel Abstract]
        ASC[AdhocSignalingChannel<br/>URL/Base64]
        WSSC[WebSocketSignalingChannel<br/>WebSocket + Rooms]
    end

    PRESENTATION --> CONTROLLER
    CONTROLLER --> MODEL
    MODEL --> TRANSPORT

    classDef noFrame stroke:#fff,stroke-width:0px;
```

### 3.2 File Structure

```text
src/peer-to-peer-chat/
├── index.html                    # 1:1 chat entry point
├── main.js                       # Bootstrap & element registration
├── signaling-server.js           # WebSocket server + Vite plugin
├── PROGRESS.md                   # Development changelog
├── SPECIFICATION.md              # This document
├── classes/                      # Core business logic (UI-agnostic)
│   ├── index.js                  # Barrel exports
│   ├── signaling-channel.js      # Abstract base class
│   ├── adhoc-signaling-channel.js
│   ├── websocket-signaling-channel.js
│   ├── peer.js                   # Peer identity model
│   ├── peers.js                  # Peer collection with state
│   ├── peer-connection.js        # RTCPeerConnection wrapper
│   ├── peer-connections.js       # Connection collection
│   ├── multi-peer-controller.js  # Mesh orchestration
│   ├── signaling-coordinator.js  # Relay routing (BFS)
│   ├── signaling-server-configuration.js
│   ├── peer-identity-manager.js
│   ├── connection-flow-controller.js
│   └── session-state-manager.js
├── elements/                     # Web Components (UI)
│   ├── helpers.js                # html/css template helpers
│   ├── types.d.ts                # TypeScript definitions
│   ├── common/styles.css         # Shared CSS variables
│   ├── multi-peer-chat-app-element.js
│   ├── peer-to-peer-chat-app-element.js
│   ├── peer-list-element.js
│   ├── chat-container-element.js
│   ├── chat-message-element.js
│   └── ...
├── debug/                        # Debugging infrastructure
│   ├── index.js                  # DebugLogger main class
│   ├── console-proxy.js          # Console interception
│   ├── debug-channel.js          # BroadcastChannel logging
│   └── shared-worker.js          # Log aggregation worker
├── multi-peer/                   # Multi-peer demo
│   ├── index.html
│   └── main.js
└── tests/                        # Test specifications
```

## 4. Core Components

### 4.1 Peer

**File:** `classes/peer.js`

Represents a peer's identity in the network.

```typescript
interface Peer {
  readonly id: string;      // Unique identifier (UUID)
  name: string;             // Display name (mutable)

  toJSON(): { id: string, name: string };
  static fromJSON(json: { id: string, name: string }): Peer;
  static generate(name?: string): Peer;
}
```

**Design Decisions:**

- **Immutable ID**: Generated once per browser session/tab using `crypto.randomUUID()`
- **Mutable name**: Can be changed at any time and broadcast to peers
- **No persistence**: ID regenerates on page reload (intentional for privacy)

### 4.2 Peers (Collection)

**File:** `classes/peers.js`

Collection manager for tracking all known peers and their states.

```typescript
type PeerConnectionState = 'discovered' | 'connecting' | 'connected' | 'disconnected';
type PeerStrategy = 'mesh' | 'server-based';

interface Peers extends EventTarget {
  add(peer: Peer, initialState?: PeerConnectionState, strategy?: PeerStrategy): void;
  remove(peerId: string): boolean;
  setState(peerId: string, state: PeerConnectionState): void;
  getState(peerId: string): PeerConnectionState | undefined;
  getStrategy(peerId: string): PeerStrategy | undefined;
  get(peerId: string): Peer | undefined;
  getConnected(): Peer[];
  getByStrategy(strategy: PeerStrategy): Peer[];
}
```

**State Transitions:**

```mermaid
stateDiagram-v2
    [*] --> discovered
    discovered --> connecting
    connecting --> connected
    connecting --> disconnected
    connected --> disconnected
    disconnected --> [*]
```

### 4.3 PeerConnection

**File:** `classes/peer-connection.js`

Wraps `RTCPeerConnection` with signaling and data channel management.

```typescript
type ConnectionState = 'new' | 'connecting' | 'connected' | 'disconnected' | 'failed' | 'closed';

interface PeerConnection extends EventTarget {
  readonly state: ConnectionState;
  readonly localPeer: Peer;
  readonly remotePeer: Peer | null;
  readonly isOfferer: boolean;

  createOffer(): Promise<RTCSessionDescriptionInit>;
  createAnswer(offer: RTCSessionDescriptionInit): Promise<RTCSessionDescriptionInit>;
  sendMessage(content: string): void;
  sendSystemMessage(action: string, payload?: unknown): void;
  close(): void;
}
```

**Key Features:**

- **ICE candidate queuing** (MAJOR-FIX-251211-02): Queues candidates until remote description is set
- **Automatic identity exchange**: Sends peer info on channel open
- **System message routing**: Handles relay signaling, peer lists, name updates

### 4.4 PeerConnections (Collection)

**File:** `classes/peer-connections.js`

Manages multiple simultaneous WebRTC connections with event aggregation.

## 5. Signaling Infrastructure

### 5.1 SignalingChannel (Abstract Base)

**File:** `classes/signaling-channel.js`

```typescript
type SignalingState = 'disconnected' | 'connecting' | 'connected';
type SignalType = 'offer' | 'answer' | 'ice-candidate';

interface SignalMessage {
  type: SignalType;
  payload: RTCSessionDescriptionInit | RTCIceCandidateInit | null;
}

abstract class SignalingChannel extends EventTarget {
  state: SignalingState;
  abstract send(message: SignalMessage): Promise<void>;
  abstract close(): void;
}
```

### 5.2 AdhocSignalingChannel

**File:** `classes/adhoc-signaling-channel.js`

Manual out-of-band signaling via URL-encoded offers/answers.

**Signal Format (FIX-251227-04):**

Signals use a prefix-based format with the offerId embedded directly in the SDP:

```text
offer:Base64(sdp)
answer:Base64(sdp)
```

The `offerId` is embedded in the SDP as an `i=oid:<offerId>` line (session information per RFC 4566), injected after the `o=` line:

```text
v=0
o=- 4850667423592740000 2 IN IP4 127.0.0.1
i=oid:4850667423592740000
s=-
...
```

**API (Internal):**

The internal API still uses `{ offerId, offer/answer }` objects for convenience. The `encode()` method automatically injects the offerId into the SDP and produces the prefix format:

```typescript
// Internal representation (used by code)
interface OfferSignal {
  offerId: string;           // Session ID for answer matching
  offer: string;             // SDP string (contains ICE candidates inline)
}

interface AnswerSignal {
  offerId: string;           // Must match the offer's offerId
  answer: string;            // SDP string (contains ICE candidates inline)
}

// encode({ offerId, offer }) → "offer:Base64(sdpWithOid)"
// decode("offer:Base64(sdpWithOid)") → { offerId, offer }
```

**SDP Session ID Extraction:**

The `offerId` is typically derived from the SDP `o=` (origin) line:

```text
o=<username> <sess-id> <sess-version> <nettype> <addrtype> <address>
```

Example: `o=- 4850667423592740000 2 IN IP4 127.0.0.1`

The `sess-id` (4850667423592740000) uniquely identifies the session.

**Static Methods:**

```javascript
// FIX-251227-04: New prefix format methods
static injectOfferId(sdp, offerId);     // Insert i=oid: line after o= line
static extractOfferId(sdp);             // Extract offerId from i=oid: line
static encodeSignal(type, sdp);         // Encode as "type:Base64(sdp)"
static decodeSignal(encoded);           // Decode to { type, offerId, sdp }

// Convenience methods (use new format internally)
static encode(signal);                  // { offerId, offer/answer } → prefix format
static decode(encoded);                 // prefix format → { offerId, offer/answer }
static createOfferUrl(baseUrl, signal); // Create shareable URL
static extractOfferFromUrl(url);        // Extract offer from URL
```

**Design Decisions:**

1. After ICE gathering completes, read `localDescription.sdp` which contains ICE candidates as `a=candidate:` lines. The SDP is self-contained.
2. The `offer:` / `answer:` prefix format eliminates JSON overhead.
3. Embedding offerId in SDP as `i=oid:` uses standard RFC 4566 session information field.
4. QR codes use error correction level 'L' (optimal for screen-to-screen scanning).

**Signal Size Comparison:**

The following table shows the signal size at each optimization stage, using a realistic offer SDP with 5 ICE candidates (1093 chars raw):

| Stage                     | Format                                   | Offer Size  | Savings | QR Version    |
| ------------------------- | ---------------------------------------- | ----------- | ------- | ------------- |
| Baseline (pre-FIX-251227) | `{ type, offerId, payload, candidates }` | ~2100 chars | —       | V40 (177×177) |
| FIX-251227-01             | `{ offerId, offer }` (ICE inline)        | 1548 chars  | 26%     | V29 (133×133) |
| FIX-251227-04             | `offer:base64(sdp)`                      | 1502 chars  | 28%     | V28 (129×129) |
| Compression*              | text-opt + zlib + dict                   | 524 chars   | 75%     | V16 (81×81)   |

*Compression requires the `fflate` library (~8KB gzipped). See `experiments/bundle-size-optimization-experiment.js`.

**QR Code Comparison Images:**

Generated using the same `qrcode-generator` library as the demo. See [assets/qr-comparison/](assets/qr-comparison/) for SVG files.

| FIX-251227-01 (1548 chars)                     | FIX-251227-04 (1502 chars)                     | Compressed (524 chars)                      |
| ---------------------------------------------- | ---------------------------------------------- | ------------------------------------------- |
| ![V29](assets/qr-comparison/fix-251227-01.svg) | ![V28](assets/qr-comparison/fix-251227-04.svg) | ![V16](assets/qr-comparison/compressed.svg) |
| V29 (133×133 modules)                          | V28 (129×129 modules)                          | V16 (81×81 modules)                         |
| ~17,689 modules²                               | ~16,641 modules²                               | ~6,561 modules²                             |

The compression strategy reduces QR code area by approximately 63% (from 17,689 to 6,561 modules²), making scanning significantly faster and more reliable on lower-resolution cameras.

To regenerate these images: `node src/peer-to-peer-chat/experiments/generate-qr-comparison-images.js`

**Future Optimization (TODO):**

Integrate `fflate` compression with SDP dictionary for production use. This would reduce offer URLs from ~1500 chars to ~500 chars, enabling:

- Faster QR code scanning
- Smaller URLs for sharing via messaging apps
- Better compatibility with URL length limits

### 5.3 WebSocketSignalingChannel

**File:** `classes/websocket-signaling-channel.js`

WebSocket-based signaling with room support.

```typescript
interface ServerCapabilities {
  routeBasedRooms: boolean;   // /api/signaling/{roomId}
  queryBasedRooms: boolean;   // ?room={roomId}
}

class WebSocketSignalingChannel extends SignalingChannel {
  constructor(url: string, roomId?: string);
  connect(): Promise<void>;
  joinRoom(peerId: string, peerName: string): Promise<PeerInfo[]>;
  sendTo(targetPeerId: string, message: SignalMessage): Promise<void>;
}
```

### 5.4 Signaling Server Protocol

**File:** `signaling-server.js`

| Direction | Type            | Payload                   | Description            |
| --------- | --------------- | ------------------------- | ---------------------- |
| C→S       | `room-join`     | `{ peerId, peerName }`    | Join room              |
| C→S       | `room-leave`    | `{ peerId }`              | Leave room             |
| C→S       | `offer`         | RTCSessionDescriptionInit | Forward offer          |
| C→S       | `answer`        | RTCSessionDescriptionInit | Forward answer         |
| C→S       | `ice-candidate` | RTCIceCandidateInit       | Forward ICE candidate  |
| S→C       | `room-peers`    | `{ roomId, peers[] }`     | Existing peers in room |
| S→C       | `peer-joined`   | `{ peerId, peerName }`    | New peer joined        |
| S→C       | `peer-left`     | `{ peerId }`              | Peer left              |
| S→C       | `capabilities`  | ServerCapabilities        | Server features        |

## 6. Multi-Peer Mesh Networking

### 6.1 MultiPeerController

**File:** `classes/multi-peer-controller.js`

Orchestrates multi-peer WebRTC mesh networking.

```typescript
type MultiPeerState = 'disconnected' | 'joining' | 'connected';

class MultiPeerController extends EventTarget {
  readonly state: MultiPeerState;
  readonly peers: Peers;
  readonly connections: PeerConnections;
  strategy: PeerStrategy;

  joinRoom(signalingUrl: string, roomId: string): Promise<PeerInfo[]>;
  leaveRoom(): void;
  addAdhocConnection(connection: PeerConnection, peer: Peer): void;
  broadcast(content: string): void;
}
```

### 6.2 SignalingCoordinator

**File:** `classes/signaling-coordinator.js`

Coordinates signaling across primary WebSocket channel and peer-to-peer relay.

```typescript
interface RelaySignalPayload {
  messageId: string;          // UUID for deduplication
  targetPeerId: string;       // Final destination
  fromPeerId: string;         // Original sender
  hopCount: number;           // Current hop count
  maxHops: number;            // Limit (default: 5)
  relayPath: string[];        // Peers traversed (loop detection)
  strategy: PeerStrategy;     // Strategy isolation
  signal: { type: string, payload: unknown };
}
```

**Routing Algorithm:**

1. **Primary Channel First:** If WebSocket connected, use it directly
2. **Route Cache Check:** Look for cached path (invalidated on topology change)
3. **BFS Discovery:** Breadth-first search through connected peers
4. **Relay with Loop Detection:** Forward via data channels, tracking path

### 6.3 Server-Based Room Join

```mermaid
sequenceDiagram
    participant A as Peer A (newcomer)
    participant S as Signaling Server
    participant BCD as Peers B, C, D

    A->>S: room-join
    S->>A: room-peers [B, C, D]
    S->>BCD: peer-joined [A]

    A->>S: offer (to B)
    S->>BCD: forward offer
    BCD->>S: answer (from B)
    S->>A: forward answer

    Note over A,BCD: WebRTC DataChannel established
```

### 6.4 Adhoc Mesh Expansion via Relay

```mermaid
sequenceDiagram
    participant A as Peer A
    participant B as Peer B
    participant C as Peer C

    Note over A,B: Already connected via WebRTC

    B->>A: peer-list [B has: C]
    Note over A: Discovers C, needs connection

    A->>B: relay-signal (offer to C)
    B->>C: relay-signal (forward)
    C->>B: relay-signal (answer from C)
    B->>A: relay-signal (forward)

    Note over A,C: Direct WebRTC established
```

## 7. Data Flow & Protocols

### 7.1 Data Channel Message Types

```typescript
// Chat message
interface ChatMessage {
  type: 'chat';
  id: string;           // UUID
  content: string;
  timestamp: string;    // ISO 8601
  senderId: string;
  senderName: string;
}

// System message
interface SystemMessage {
  type: 'system';
  action: 'peer-info' | 'name-update' | 'peer-list' | 'relay-signal';
  payload?: unknown;
}
```

### 7.2 ICE Candidate Handling

**Problem (MAJOR-FIX-251211-02):** ICE candidates can arrive before `setRemoteDescription()` completes.

**Solution:** Queue candidates and flush after remote description is set.

```javascript
class PeerConnection {
  #pendingIceCandidates = [];
  #remoteDescriptionSet = false;

  async #addIceCandidate(candidate) {
    if (!candidate?.candidate) return; // Skip empty (end-of-candidates)

    if (this.#remoteDescriptionSet) {
      await this.#rtcConnection.addIceCandidate(new RTCIceCandidate(candidate));
    } else {
      this.#pendingIceCandidates.push(candidate);
    }
  }

  async #flushPendingIceCandidates() {
    this.#remoteDescriptionSet = true;
    for (const candidate of this.#pendingIceCandidates) {
      await this.#rtcConnection.addIceCandidate(new RTCIceCandidate(candidate));
    }
    this.#pendingIceCandidates = [];
  }
}
```

## 8. UI Components

### 8.1 Component Hierarchy

```mermaid
graph LR
    MPCA["multi-peer-chat-app"]

    subgraph Components[" "]
      direction TB
      subgraph MPCADialogs[" "]
        AOD["adhoc-offer-dialog"]
        AAD["adhoc-answer-dialog"]
        SAD["submit-answer-dialog"]
      end
      subgraph MPCAComponents[" "]
        CP["#connection-panel"]
        PL["peer-list"]
        CC["chat-container"]
      end
      subgraph CCComponents[" "]
        CS["chat-section"]
        CM["chat-message"]
      end
      STF["sharable-text-field"]
    end
   class Components,MPCADialogs,MPCAComponents,CCComponents noFrame;

    MPCA --> CP
    MPCA --> AOD
    MPCA --> AAD
    MPCA --> SAD
    MPCA --> PL
    MPCA --> CC
    AOD --> STF
    SAD --> STF
    CC --> CS
    CC --> CM

    classDef noFrame fill:#0000,stroke:#fff,stroke-width:0px;
```

### 8.2 PeerListElement States

| State        | Indicator        |
| ------------ | ---------------- |
| connected    | Green            |
| connecting   | Yellow (pulsing) |
| discovered   | Gray             |
| disconnected | Red              |

## 9. State Management

### 9.1 Storage Strategy

| Data          | Storage        | Scope   | Rationale                                     |
| ------------- | -------------- | ------- | --------------------------------------------- |
| Peer ID       | Memory         | Session | Privacy: regenerates per tab                  |
| Display Name  | sessionStorage | Tab     | Allows different names per tab during testing |
| Pet-Names     | localStorage   | Browser | Persistent nicknames for known peers          |
| Messages      | Memory         | Session | No persistence by design                      |
| Signaling URL | sessionStorage | Tab     | Tab-specific server configuration             |

**Design Decision:** Using sessionStorage (not localStorage) for tab-specific state prevents cross-tab conflicts when testing multi-peer scenarios with multiple tabs.

### 9.2 SessionStateManager Keys

```javascript
static KEYS = {
  DISPLAY_NAME: 'peer-to-peer-chat/session/display-name',
  SIGNALING_URL: 'peer-to-peer-chat/session/signaling-url',
  SIGNALING_ENABLED: 'peer-to-peer-chat/session/signaling-enabled',
  ROOM_ID: 'peer-to-peer-chat/session/room-id',
  STRATEGY: 'peer-to-peer-chat/session/strategy',
  PET_NAMES: 'peer-to-peer-chat/session/pet-names',
};
```

## 10. Debug Infrastructure

### 10.1 Architecture

```mermaid
flowchart TB
    subgraph Tab1["Tab 1"]
        CP1[Console Proxy] --> DL1[DebugLogger]
        EH1[Error Handlers] --> DL1
    end

    subgraph Tab2["Tab 2"]
        CP2[Console Proxy] --> DL2[DebugLogger]
    end

    DL1 --> |BroadcastChannel| SW[SharedWorker<br/>Log Aggregation]
    DL2 --> |BroadcastChannel| SW
    SW --> Console[Worker Console Output]
```

### 10.2 Components

| File                | Purpose                                                  |
| ------------------- | -------------------------------------------------------- |
| `console-proxy.js`  | Wraps `console.*` methods to capture calls               |
| `error-handlers.js` | Captures `window.onerror` and unhandled rejections       |
| `debug-channel.js`  | BroadcastChannel wrapper for cross-tab communication     |
| `shared-worker.js`  | Aggregates logs from all tabs, outputs to worker console |

## 11. Security Considerations

### 11.1 Security Model

| Aspect               | Implementation                          |
| -------------------- | --------------------------------------- |
| Transport Encryption | DTLS-SRTP (mandatory in WebRTC)         |
| Peer Authentication  | Peer ID verification via data channel   |
| ICE Security         | STUN servers only (no TURN credentials) |

### 11.2 Known Limitations

- No end-to-end encryption of chat messages (relies on DTLS)
- No authentication/authorization in signaling server
- Relay routing exposes message metadata to intermediate peers
- No message persistence or history

## 12. API Reference

### 12.1 Custom Element Registration

```javascript
// main.js - 1:1 chat
customElements.define('peer-to-peer-chat-app', PeerToPeerChatAppElement);

// multi-peer/main.js - Multi-peer chat
customElements.define('multi-peer-chat-app', MultiPeerChatAppElement);
customElements.define('peer-list', PeerListElement);
```

### 12.2 Element Attributes

#### `<multi-peer-chat-app>`

| Attribute              | Values | Description                    |
| ---------------------- | ------ | ------------------------------ |
| `signaling-server-url` | URL    | Pre-configure signaling server |
| `room-id`              | string | Pre-configure room ID          |

#### `<peer-to-peer-chat-app>`

| Value             | Mode         | Behavior                      |
| ----------------- | ------------ | ----------------------------- |
| (empty)           | `default`    | User configures               |
| `"ws://..."`      | `configured` | Pre-filled, user can override |
| `"only:ws://..."` | `only`       | Locked, auto-connect          |
| `"disabled"`      | `disabled`   | Hide signaling UI             |

## 13. Deployment

### 13.1 Development

```bash
npm run dev -- --signaling-server     # With integrated signaling
npm run dev -- --signaling-server=9000  # Custom port
```

### 13.2 Production

```bash
npm run build                          # Static files to dist/
node signaling-server.js 8080          # Standalone server
node signaling-server.js 8443 --tls    # With TLS
```

### 13.3 Browser Compatibility

| Feature            | Chrome | Firefox | Safari | Edge |
| ------------------ | ------ | ------- | ------ | ---- |
| WebRTC DataChannel | ✅     | ✅      | ✅     | ✅   |
| Custom Elements v1 | ✅     | ✅      | ✅     | ✅   |
| `light-dark()` CSS | 123+   | 120+    | 17.5+  | 123+ |
| SharedWorker       | ✅     | ✅      | ❌     | ✅   |

## Appendix A: Aspect ID Convention

Format: `{PREFIX}-YYMMDD-XX`

| Prefix       | Description      |
| ------------ | ---------------- |
| `FEAT-`      | New feature      |
| `FIX-`       | Bug fix          |
| `MAJOR-FIX-` | Critical fix     |
| `REFACTOR-`  | Code improvement |

## Appendix B: Glossary

| Term                | Definition                                             |
| ------------------- | ------------------------------------------------------ |
| **Adhoc Signaling** | Manual offer/answer exchange via URLs (no server)      |
| **BFS Routing**     | Breadth-first search for finding relay paths           |
| **DataChannel**     | WebRTC's reliable/unreliable data transport            |
| **ICE**             | Interactive Connectivity Establishment (NAT traversal) |
| **Mesh Topology**   | Every peer connected to every other peer               |
| **Pet-Name**        | User-assigned local nickname for a remote peer         |
| **Relay Signaling** | Forwarding signals through connected peers             |
| **SDP**             | Session Description Protocol (includes ICE candidates) |

<style>
.mermaid svg { display: block; margin-left: auto; margin-right: auto; width: auto; }
@media print { h1, h2, h3, h4, h5, h6 { page-break-after: avoid; break-after: avoid-page; } }
@media print { table, figure, div.no-break { page-break-inside: avoid; break-inside: avoid-page; } }
@media print { p:has(+table, +figure, +div.no-break) { page-break-before: avoid; break-before: avoid; page-break-inside: avoid; break-inside: avoid-page; page-break-after: avoid; break-after: avoid-page; } }
</style>
<script type="module">
  import mermaid from 'https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.esm.min.mjs';
  [...document.querySelectorAll('pre:has(> code:first-child:last-child.lang-mermaid)') ].forEach(pre => { Object.assign(pre, {className: 'mermaid', innerHTML: pre.innerText}) });
  mermaid.initialize({ startOnLoad: true });
</script>
