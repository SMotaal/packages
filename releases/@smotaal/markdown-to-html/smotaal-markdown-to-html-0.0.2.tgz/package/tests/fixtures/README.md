# Peer-to-Peer Chat Tests

> **Reading Guide**: This document uses clear headings, short sentences, and tables for easy reading.

## Quick Reference

| Document                                 | What It Covers                                 |
| ---------------------------------------- | ---------------------------------------------- |
| [UNIT-TESTS](./UNIT-TESTS)               | Tests for single classes in isolation          |
| [INTEGRATION-TESTS](./INTEGRATION-TESTS) | Tests for multiple classes working together    |
| [END-TO-END-TESTS](./END-TO-END-TESTS)   | Tests for full user workflows in real browsers |

## Test Counts

| Type        | File Count   | Total Tests   |
| ----------- | ------------ | ------------- |
| Unit        | 8 files      | 187 tests     |
| Integration | 7 files      | 158 tests     |
| End-to-End  | 6 files      | 131 tests     |
| **Total**   | **21 files** | **476 tests** |

## How to Run Tests

```bash
# Run all tests (dev mode)
yarn test

# Run all tests (production build)
yarn test:build

# Run specific test file
yarn vitest run src/peer-to-peer-chat/tests/signaling.spec.ts

# Run with debug browser (headed mode)
VITE_DEBUG_SERVE=1 yarn test
```

## Test File Naming

All test files use the pattern: `{what-it-tests}.spec.ts`

| Pattern                | Meaning                  |
| ---------------------- | ------------------------ |
| `*.spec.ts`            | TypeScript test file     |
| `*-element.spec.ts`    | Tests a custom element   |
| `*-controller.spec.ts` | Tests a controller class |
| `*-manager.spec.ts`    | Tests a manager class    |

## Test Categories

### Unit Tests (8 files)

Tests for **single classes in isolation**. Most run in browser via Playwright.

| File                                     | Tests                                   | Environment |
| ---------------------------------------- | --------------------------------------- | ----------- |
| `signaling.spec.ts`                      | AdhocSignalingChannel + Peer (21 tests) | Browser     |
| `peers.spec.ts`                          | Peers collection (34 tests)             | Browser     |
| `peer-connections.spec.ts`               | PeerConnections collection (19 tests)   | Browser     |
| `signaling-server-configuration.spec.ts` | URL and mode parsing (31 tests)         | Browser     |
| `peer-identity-manager.spec.ts`          | localStorage identity (15 tests)        | Browser     |
| `session-state-manager.spec.ts`          | sessionStorage state (23 tests)         | Browser     |
| `connection-flow-controller.spec.ts`     | State machine (18 tests)                | Browser     |
| `signaling-protocol.spec.ts`             | Protocol validation (26 tests)          | Node.js     |

### Integration Tests (7 files)

Tests for **multiple classes working together**. May use mocks.

| File                                   | Tests                                       | Environment |
| -------------------------------------- | ------------------------------------------- | ----------- |
| `signaling-coordinator.spec.ts`        | Coordinator + channels (37 tests)           | Browser     |
| `multi-peer-controller.spec.ts`        | Controller + peers + connections (31 tests) | Browser     |
| `peer-list-exchange.spec.ts`           | Peer discovery protocol (24 tests)          | Browser     |
| `signaling-server-integration.spec.ts` | Real WebSocket server (29 tests)            | Node.js     |
| `signaling-cloudflare.spec.ts`         | Cloudflare Durable Object (11 tests)        | Node.js     |
| `debug-logger.spec.ts`                 | Console proxy + SharedWorker (17 tests)     | Browser     |
| `test-isolation.spec.ts`               | Browser state isolation (9 tests)           | Browser     |

### End-to-End Tests (6 files)

Tests for **full user workflows** in real browsers.

| File                             | Tests                                |
| -------------------------------- | ------------------------------------ |
| `demo-flow.spec.ts`              | Complete user flow (12 tests)        |
| `multi-peer-app-element.spec.ts` | Full app element (36 tests)          |
| `peer-list-element.spec.ts`      | Peer list UI (24 tests)              |
| `step-elements.spec.ts`          | Step container UI (25 tests)         |
| `multi-peer-signaling.spec.ts`   | WebSocket signaling API (14 tests)   |
| `multi-peer-mesh.spec.ts`        | Multi-browser WebRTC mesh (20 tests) |

## Test Infrastructure

### Files That Support Tests

| File                          | Purpose                         |
| ----------------------------- | ------------------------------- |
| `index.html`                  | Loads test modules in browser   |
| `vitest.config.js`            | Main test configuration         |
| `vitest-global-test-setup.ts` | Starts Vite server + browser    |
| `vitest-test-setup.ts`        | Creates page for each test file |

### Browser Environment

- **Browser**: Chromium via Playwright
- **Mode**: Headless by default
- **HTTPS**: Self-signed certificates (ignored in tests)
- **Port**: Dynamic (port 0) to avoid conflicts

### Server Environment

- **Dev Mode**: Vite dev server with HMR
- **Build Mode**: Production build + preview server
- **Timeout**: 30 seconds per test

## Limitations

> **Important**: These limitations mean tests may pass when code is broken, or fail when code is correct.

### Known Limitations

| Limitation            | Impact                                     | Mitigation                 |
| --------------------- | ------------------------------------------ | -------------------------- |
| Closed shadow DOM     | Cannot directly inspect internal UI        | Use public APIs only       |
| WebSocket bypass      | `page.route()` cannot intercept WebSockets | Explicit signaling URL     |
| Timing-dependent      | WebRTC events are asynchronous             | Use `waitFor*` helpers     |
| Single browser server | All tests share one Chromium               | Separate contexts per test |

### Things Tests Cannot Verify

1. **Visual appearance** - Tests check behavior, not styling
2. **Real network conditions** - Tests run on localhost
3. **Real user input** - Tests use programmatic API calls
4. **Memory leaks** - No long-running tests
5. **Actual cross-origin** - Virtual origins simulate, not real

### When Tests May Give Wrong Results

| Situation       | Why It Happens                               |
| --------------- | -------------------------------------------- |
| Race conditions | Async operations complete in different order |
| Stale modules   | Browser caches old module versions           |
| Port conflicts  | Another process uses same port               |
| Slow machine    | Timeouts trigger before completion           |

## Validation Checklist

Use this when reviewing tests:

- [ ] Does the test file name match what it tests?
- [ ] Does each `describe` block have a clear purpose?
- [ ] Does each `test` have a clear assertion?
- [ ] Are async operations properly awaited?
- [ ] Are timeouts appropriate for what's being tested?
- [ ] Does the test clean up after itself?
- [ ] Could the test pass with broken code? (false positive)
- [ ] Could the test fail with working code? (false negative)

## File Structure

```text
src/peer-to-peer-chat/tests/
├── README.md                           # This file
├── UNIT-TESTS.md                       # Unit test documentation
├── INTEGRATION-TESTS.md                # Integration test documentation
├── END-TO-END-TESTS.md                 # E2E test documentation
├── index.html                          # Test module loader
├── signaling.spec.ts                   # Unit (21 tests)
├── peers.spec.ts                       # Unit (34 tests)
├── peer-connections.spec.ts            # Unit (19 tests)
├── signaling-server-configuration.spec.ts # Unit (31 tests)
├── peer-identity-manager.spec.ts       # Unit (15 tests)
├── session-state-manager.spec.ts       # Unit (23 tests)
├── connection-flow-controller.spec.ts  # Unit (18 tests)
├── signaling-protocol.spec.ts          # Unit (26 tests, Node.js)
├── signaling-coordinator.spec.ts       # Integration (37 tests)
├── multi-peer-controller.spec.ts       # Integration (31 tests)
├── peer-list-exchange.spec.ts          # Integration (24 tests)
├── signaling-server-integration.spec.ts # Integration (29 tests, Node.js)
├── signaling-cloudflare.spec.ts        # Integration (11 tests, Node.js)
├── debug-logger.spec.ts                # Integration (17 tests)
├── test-isolation.spec.ts              # Integration (9 tests)
├── demo-flow.spec.ts                   # E2E (12 tests)
├── multi-peer-app-element.spec.ts      # E2E (36 tests)
├── peer-list-element.spec.ts           # E2E (24 tests)
├── step-elements.spec.ts               # E2E (25 tests)
├── multi-peer-signaling.spec.ts        # E2E (14 tests)
└── multi-peer-mesh.spec.ts             # E2E (20 tests)
```

## Related Documentation

- [PROGRESS.md](../PROGRESS.md) - Feature and fix history
- [CLAUDE.md](../../../CLAUDE.md) - Development guidelines
- `tests/helpers/` - Test infrastructure code

<style>
.mermaid svg { display: block; margin-left: auto; margin-right: auto; width: auto; }
@media print { h1, h2, h3, h4, h5, h6 { page-break-after: avoid; break-after: avoid-page; } }
@media print { table, figure, div.no-break { page-break-inside: avoid; break-inside: avoid-page; } }
@media print { p:has(+table, +figure, +div.no-break) { page-break-before: avoid; break-before: avoid; page-break-inside: avoid; break-inside: avoid-page; page-break-after: avoid; break-after: avoid-page; } }
</style>
<script type="module">
  import mermaid from 'https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.esm.min.mjs';
  [...document.querySelectorAll('pre:has(> code:first-child:last-child.lang-mermaid)') ].forEach(pre => { Object.assign(pre, {className: 'mermaid', innerHTML: pre.innerText}) });
  mermaid.initialize({ startOnLoad: true });
</script>
