// @ts-check
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { renderMarkdown, renderMarkdownRaw } from '../src/renderer.js';

describe('renderMarkdown', () => {
	const originalFetch = global.fetch;

	beforeEach(() => {
		// Reset fetch mock before each test
		vi.resetAllMocks();
	});

	afterEach(() => {
		// Restore original fetch
		global.fetch = originalFetch;
	});

	it('should call GitHub API with correct parameters', async () => {
		const mockResponse = {
			ok: true,
			text: async () => '<p>rendered content</p>',
			headers: new Map(),
		};
		global.fetch = vi.fn().mockResolvedValue(mockResponse);

		const result = await renderMarkdown('# Test', { mode: 'gfm' });

		expect(global.fetch).toHaveBeenCalledWith(
			'https://api.github.com/markdown',
			expect.objectContaining({
				method: 'POST',
				headers: expect.objectContaining({
					'Accept': 'application/vnd.github+json',
					'X-GitHub-Api-Version': '2022-11-28',
					'Content-Type': 'application/json',
				}),
			})
		);
		expect(result).toBe('<p>rendered content</p>');
	});

	it('should include authorization header when token provided', async () => {
		const mockResponse = {
			ok: true,
			text: async () => '<p>rendered</p>',
			headers: new Map(),
		};
		global.fetch = vi.fn().mockResolvedValue(mockResponse);

		await renderMarkdown('# Test', { token: 'test-token' });

		const call = /** @type {import('vitest').Mock} */ (global.fetch).mock.calls[0];
		const headers = call[1].headers;
		expect(headers['Authorization']).toBe('Bearer test-token');
	});

	it('should throw on rate limit error with reset time', async () => {
		const resetTime = Math.floor(Date.now() / 1000) + 3600;
		const mockResponse = {
			ok: false,
			status: 403,
			text: async () => 'Rate limit exceeded',
			headers: {
				get: (name) => {
					if (name === 'x-ratelimit-remaining') return '0';
					if (name === 'x-ratelimit-reset') return String(resetTime);
					return null;
				},
			},
		};
		global.fetch = vi.fn().mockResolvedValue(mockResponse);

		await expect(renderMarkdown('# Test')).rejects.toThrow('rate limit exceeded');
	});

	it('should throw on API error with status code', async () => {
		const mockResponse = {
			ok: false,
			status: 500,
			text: async () => 'Internal server error',
			headers: {
				get: () => null,
			},
		};
		global.fetch = vi.fn().mockResolvedValue(mockResponse);

		await expect(renderMarkdown('# Test')).rejects.toThrow('GitHub API error (500)');
	});

	it('should include context when provided', async () => {
		const mockResponse = {
			ok: true,
			text: async () => '<p>rendered</p>',
			headers: new Map(),
		};
		global.fetch = vi.fn().mockResolvedValue(mockResponse);

		await renderMarkdown('# Test', { context: 'owner/repo' });

		const call = /** @type {import('vitest').Mock} */ (global.fetch).mock.calls[0];
		const body = JSON.parse(call[1].body);
		expect(body.context).toBe('owner/repo');
	});
});

describe('renderMarkdownRaw', () => {
	afterEach(() => {
		vi.resetAllMocks();
	});

	it('should send plain text content', async () => {
		const mockResponse = {
			ok: true,
			text: async () => '<p>raw rendered</p>',
		};
		global.fetch = vi.fn().mockResolvedValue(mockResponse);

		const result = await renderMarkdownRaw('# Test');

		const call = /** @type {import('vitest').Mock} */ (global.fetch).mock.calls[0];
		expect(call[0]).toBe('https://api.github.com/markdown/raw');
		expect(call[1].headers['Content-Type']).toBe('text/plain');
		expect(call[1].body).toBe('# Test');
		expect(result).toBe('<p>raw rendered</p>');
	});
});
