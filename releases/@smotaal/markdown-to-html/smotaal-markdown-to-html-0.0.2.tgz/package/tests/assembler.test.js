// @ts-check
import { describe, it, expect } from 'vitest';
import { extractTitle, assembleDocument } from '../src/assembler.js';

describe('extractTitle', () => {
	it('should extract title from H1', () => {
		const html = '<h1>My Document</h1><p>Content</p>';
		expect(extractTitle(html)).toBe('My Document');
	});

	it('should return null when no H1 present', () => {
		const html = '<h2>Heading 2</h2><p>Content</p>';
		expect(extractTitle(html)).toBeNull();
	});

	it('should handle H1 with attributes', () => {
		const html = '<h1 class="title" id="main">Title With Attrs</h1>';
		expect(extractTitle(html)).toBe('Title With Attrs');
	});

	it('should trim whitespace from title', () => {
		const html = '<h1>  Padded Title  </h1>';
		expect(extractTitle(html)).toBe('Padded Title');
	});
});

describe('assembleDocument', () => {
	it('should create valid HTML5 document', () => {
		const body = '<p>Test content</p>';
		const result = assembleDocument(body);

		expect(result).toContain('<!DOCTYPE html>');
		expect(result).toContain('<html lang="en">');
		expect(result).toContain('<meta charset="utf-8">');
		expect(result).toContain('<meta name="viewport"');
		expect(result).toContain('</html>');
	});

	it('should use extracted title', () => {
		const body = '<h1>My Page</h1><p>Content</p>';
		const result = assembleDocument(body);

		expect(result).toContain('<title>My Page</title>');
	});

	it('should use provided title over extracted', () => {
		const body = '<h1>Extracted</h1><p>Content</p>';
		const result = assembleDocument(body, { title: 'Custom Title' });

		expect(result).toContain('<title>Custom Title</title>');
	});

	it('should fall back to Document when no title', () => {
		const body = '<p>No heading</p>';
		const result = assembleDocument(body);

		expect(result).toContain('<title>Document</title>');
	});

	it('should wrap body in markdown-body article', () => {
		const body = '<p>Test</p>';
		const result = assembleDocument(body);

		expect(result).toContain('<article class="markdown-body">');
		expect(result).toContain('<p>Test</p>');
		expect(result).toContain('</article>');
	});

	it('should include styles as inline style tags', () => {
		const styles = ['.test { color: red; }'];
		const result = assembleDocument('<p>Test</p>', { styles });

		expect(result).toContain('<style>');
		expect(result).toContain('.test { color: red; }');
		expect(result).toContain('</style>');
	});

	it('should include scripts as inline script tags', () => {
		const scripts = ['console.log("hello");'];
		const result = assembleDocument('<p>Test</p>', { scripts });

		expect(result).toContain('<script type="module">');
		expect(result).toContain('console.log("hello");');
		expect(result).toContain('</script>');
	});

	it('should include script URLs as external modules', () => {
		const scriptURLs = ['https://example.com/script.js'];
		const result = assembleDocument('<p>Test</p>', { scriptURLs });

		expect(result).toContain('<script type="module" src="https://example.com/script.js"></script>');
	});

	it('should set theme via data attribute', () => {
		const result = assembleDocument('<p>Test</p>', { theme: 'dark' });

		expect(result).toContain('data-color-mode="dark"');
	});

	it('should not add theme attribute for auto theme', () => {
		const result = assembleDocument('<p>Test</p>', { theme: 'auto' });

		expect(result).not.toContain('data-color-mode');
	});

	it('should escape HTML in title', () => {
		const result = assembleDocument('<p>Test</p>', { title: '<script>alert("xss")</script>' });

		expect(result).toContain('&lt;script&gt;');
		expect(result).not.toContain('<script>alert');
	});

	it('should preserve UTF-8 characters', () => {
		const body = `<p>Unicode: → ← ↔ — ' ' " " … × ÷</p>`;
		const result = assembleDocument(body, { title: `Тест ñ ü é` });

		expect(result).toContain('→');
		expect(result).toContain('←');
		expect(result).toContain('—');
		expect(result).toContain('Тест');
		expect(result).toContain('ñ');
	});
});
