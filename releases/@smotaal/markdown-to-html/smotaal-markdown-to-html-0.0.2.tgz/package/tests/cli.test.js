// @ts-check
import { describe, it, expect } from 'vitest';
import { parseCLI, showHelp, expandGlobs } from '../src/cli.js';

describe('parseCLI', () => {
	it('should parse positional files', () => {
		const result = parseCLI(['README.md', 'docs/guide.md']);

		expect(result.files).toEqual(['README.md', 'docs/guide.md']);
	});

	it('should parse output option with short flag', () => {
		const result = parseCLI(['-o', 'dist', 'README.md']);

		expect(result.output).toBe('dist');
		expect(result.files).toEqual(['README.md']);
	});

	it('should parse output option with long flag', () => {
		const result = parseCLI(['--output', 'dist', 'README.md']);

		expect(result.output).toBe('dist');
	});

	it('should parse theme option', () => {
		const result = parseCLI(['-t', 'dark', 'README.md']);

		expect(result.theme).toBe('dark');
	});

	it('should parse context option', () => {
		const result = parseCLI(['--context', 'owner/repo', 'README.md']);

		expect(result.context).toBe('owner/repo');
	});

	it('should parse single-file flag', () => {
		const result = parseCLI(['-s', 'README.md']);

		expect(result.singleFile).toBe(true);
	});

	it('should parse help flag', () => {
		const result = parseCLI(['--help']);

		expect(result.help).toBe(true);
	});

	it('should parse version flag', () => {
		const result = parseCLI(['-v']);

		expect(result.version).toBe(true);
	});

	it('should parse configuration option', () => {
		const result = parseCLI(['-c', 'custom.configuration.js', 'README.md']);

		expect(result.configuration).toBe('custom.configuration.js');
	});

	it('should handle multiple files with options', () => {
		const result = parseCLI(['-o', 'dist', '-t', 'light', 'a.md', 'b.md', 'c.md']);

		expect(result.output).toBe('dist');
		expect(result.theme).toBe('light');
		expect(result.files).toEqual(['a.md', 'b.md', 'c.md']);
	});
});

describe('showHelp', () => {
	it('should not throw', () => {
		// Suppress console.log during test
		const originalLog = console.log;
		console.log = () => {};

		expect(() => showHelp()).not.toThrow();

		console.log = originalLog;
	});
});

describe('expandGlobs', () => {
	it('should pass through non-glob patterns', async () => {
		const result = await expandGlobs(['README.md', 'docs/guide.md']);

		// Non-glob patterns are resolved to absolute paths
		expect(result).toHaveLength(2);
		expect(result[0]).toContain('README.md');
		expect(result[1]).toContain('docs/guide.md');
	});

	it('should return empty array for non-matching globs', async () => {
		const result = await expandGlobs(['nonexistent/**/*.md']);

		expect(result).toEqual([]);
	});

	it('should deduplicate results', async () => {
		const result = await expandGlobs(['README.md', 'README.md']);

		// Deduplicated
		expect(result).toHaveLength(1);
	});
});
