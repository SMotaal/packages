// @ts-check
import { describe, it, expect } from 'vitest';
import {
	bundleMermaid,
	bundleMermaidWithVite,
	bundleMermaidAsDataURL,
	bundleMermaidAsDataURLWithVite,
	bundleGitHubElements,
} from '../src/bundler.js';

describe('bundleMermaid', () => {
	it('should produce non-empty bundled code', async () => {
		const result = await bundleMermaid();

		expect(typeof result).toBe('string');
		expect(result.length).toBeGreaterThan(0);
	}, 60000);
});

describe('bundleMermaidWithVite', () => {
	it('should produce non-empty bundled code', async () => {
		const result = await bundleMermaidWithVite();

		expect(typeof result).toBe('string');
		expect(result.length).toBeGreaterThan(0);
	}, 60000);
});

describe('bundleMermaid vs bundleMermaidWithVite size comparison', () => {
	it('bundleMermaid output should be smaller than bundleMermaidWithVite', async () => {
		const [rollupResult, viteResult] = await Promise.all([
			bundleMermaid(),
			bundleMermaidWithVite(),
		]);

		expect(rollupResult.length).toBeLessThan(viteResult.length);
	}, 120000);
});

describe('bundleMermaidAsDataURL', () => {
	it('should return a valid data: URL', async () => {
		const result = await bundleMermaidAsDataURL();

		expect(typeof result).toBe('string');
		expect(result.startsWith('data:text/javascript;base64,')).toBe(true);
		// Verify the base64 portion is non-empty
		const base64Part = result.replace('data:text/javascript;base64,', '');
		expect(base64Part.length).toBeGreaterThan(0);
	}, 60000);
});

describe('bundleMermaidAsDataURLWithVite', () => {
	it('should return a valid data: URL', async () => {
		const result = await bundleMermaidAsDataURLWithVite();

		expect(typeof result).toBe('string');
		expect(result.startsWith('data:text/javascript;base64,')).toBe(true);
		// Verify the base64 portion is non-empty
		const base64Part = result.replace('data:text/javascript;base64,', '');
		expect(base64Part.length).toBeGreaterThan(0);
	}, 60000);
});

describe('bundleGitHubElements', () => {
	it('should return empty string for empty array', async () => {
		const result = await bundleGitHubElements([]);

		expect(result).toBe('');
	});

	it('should produce non-empty bundled code for elements', async () => {
		const result = await bundleGitHubElements(['clipboard-copy']);

		expect(typeof result).toBe('string');
		expect(result.length).toBeGreaterThan(0);
	}, 60000);
});
