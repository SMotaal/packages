// @ts-check
import { describe, it, expect } from 'vitest';
import { slugify, addHeadingIds, addHeadingAnchors, postprocess } from '../src/postprocessor.js';

describe('slugify', () => {
	it('converts simple text to lowercase slug', () => {
		expect(slugify('Hello World')).toBe('hello-world');
	});

	it('handles numbers in text', () => {
		expect(slugify('1.1 Purpose')).toBe('1-1-purpose');
	});

	it('removes special characters', () => {
		expect(slugify('What & Why?')).toBe('what-and-why');
	});

	it('handles accented characters', () => {
		expect(slugify('Caf\u00e9 Ren\u00e9')).toBe('cafe-rene');
	});

	it('removes HTML entities', () => {
		expect(slugify('A &amp; B')).toBe('a-and-b');
	});

	it('removes leading and trailing hyphens', () => {
		expect(slugify('---Leading')).toBe('leading');
		expect(slugify('Trailing---')).toBe('trailing');
	});

	it('collapses multiple hyphens', () => {
		expect(slugify('Multiple   Spaces')).toBe('multiple-spaces');
	});

	it('handles empty strings', () => {
		expect(slugify('')).toBe('');
		expect(slugify('   ')).toBe('');
	});
});

describe('addHeadingIds', () => {
	it('adds id to h1 without id', () => {
		const html = '<h1>Hello World</h1>';
		expect(addHeadingIds(html)).toBe('<h1 id="hello-world">Hello World</h1>');
	});

	it('adds id to all heading levels', () => {
		const html = '<h1>One</h1><h2>Two</h2><h3>Three</h3>';
		expect(addHeadingIds(html)).toBe(
			'<h1 id="one">One</h1><h2 id="two">Two</h2><h3 id="three">Three</h3>'
		);
	});

	it('preserves existing id attributes', () => {
		const html = '<h1 id="existing">Hello</h1>';
		expect(addHeadingIds(html)).toBe('<h1 id="existing">Hello</h1>');
	});

	it('handles headings with inline elements', () => {
		const html = '<h1>Hello <code>World</code></h1>';
		expect(addHeadingIds(html)).toBe('<h1 id="hello-world">Hello <code>World</code></h1>');
	});

	it('handles headings with nested elements', () => {
		const html = '<h1>Hello <strong><em>World</em></strong></h1>';
		expect(addHeadingIds(html)).toBe('<h1 id="hello-world">Hello <strong><em>World</em></strong></h1>');
	});

	it('handles duplicate headings by adding numeric suffix', () => {
		const html = '<h2>Overview</h2><h2>Overview</h2><h2>Overview</h2>';
		expect(addHeadingIds(html)).toBe(
			'<h2 id="overview">Overview</h2><h2 id="overview-1">Overview</h2><h2 id="overview-2">Overview</h2>'
		);
	});

	it('preserves other attributes on headings', () => {
		const html = '<h1 class="title" data-level="1">Hello</h1>';
		expect(addHeadingIds(html)).toBe('<h1 class="title" data-level="1" id="hello">Hello</h1>');
	});

	it('handles empty heading text', () => {
		const html = '<h1></h1>';
		expect(addHeadingIds(html)).toBe('<h1 id="heading"></h1>');
	});
});

describe('addHeadingAnchors', () => {
	it('adds anchor link to heading with id', () => {
		const html = '<h1 id="hello">Hello</h1>';
		expect(addHeadingAnchors(html)).toBe(
			'<h1 id="hello"><a class="anchor" aria-hidden="true" href="#hello"></a>Hello</h1>'
		);
	});

	it('does not add anchor to heading without id', () => {
		const html = '<h1>Hello</h1>';
		expect(addHeadingAnchors(html)).toBe('<h1>Hello</h1>');
	});

	it('adds anchors to multiple headings', () => {
		const html = '<h1 id="one">One</h1><h2 id="two">Two</h2>';
		expect(addHeadingAnchors(html)).toContain('href="#one"');
		expect(addHeadingAnchors(html)).toContain('href="#two"');
	});
});

describe('postprocess', () => {
	it('adds heading IDs by default', () => {
		const html = '<h1>Hello</h1>';
		expect(postprocess(html)).toBe('<h1 id="hello">Hello</h1>');
	});

	it('can disable heading IDs', () => {
		const html = '<h1>Hello</h1>';
		expect(postprocess(html, { headingIds: false })).toBe('<h1>Hello</h1>');
	});

	it('can enable heading anchors', () => {
		const html = '<h1>Hello</h1>';
		const result = postprocess(html, { headingAnchors: true });
		expect(result).toContain('id="hello"');
		expect(result).toContain('href="#hello"');
	});

	it('adds anchors after IDs when both enabled', () => {
		const html = '<h1>Hello</h1>';
		const result = postprocess(html, { headingIds: true, headingAnchors: true });
		expect(result).toBe(
			'<h1 id="hello"><a class="anchor" aria-hidden="true" href="#hello"></a>Hello</h1>'
		);
	});
});
