// @ts-check
/**
 * Global setup for vitest browser tests
 *
 * This setup handles browser server (Playwright) lifecycle management.
 * Ensures proper cleanup even on test interruption/failure.
 *
 * Environment variables:
 * - VITE_DEBUG_SERVE=1: Run browser in headed mode for debugging
 */

import { chromium } from 'playwright-chromium';

/** @type {import('playwright-chromium').BrowserServer | undefined} */
let browserServer;

// Track if cleanup has already run to prevent double-cleanup
let cleanupDone = false;

async function cleanup() {
	if (cleanupDone) return;
	cleanupDone = true;

	if (browserServer) {
		try {
			await Promise.race([
				browserServer.close(),
				new Promise(resolve => setTimeout(resolve, 1500))
			]);
		} catch {
			// Ignore - shutting down anyway
		}
		browserServer = undefined;
	}
}

// Register signal handlers for graceful shutdown on interrupts (Ctrl+C, etc.)
function registerSignalHandlers() {
	const handleSignal = async (/** @type {string} */ signal) => {
		console.log(`[vitest-browser-setup] Received ${signal}, cleaning up...`);
		await cleanup();
		process.exit(0);
	};

	process.once('SIGINT', () => handleSignal('SIGINT'));
	process.once('SIGTERM', () => handleSignal('SIGTERM'));
}

/**
 * @param {{ provide: (key: string, value: string) => void }} context
 */
export async function setup({ provide }) {
	registerSignalHandlers();

	// Start browser server
	browserServer = await chromium.launchServer({
		headless: !process.env.VITE_DEBUG_SERVE,
		args: process.env.CI
			? ['--no-sandbox', '--disable-setuid-sandbox']
			: undefined,
	});

	provide('wsEndpoint', browserServer.wsEndpoint());
	console.log('[vitest-browser-setup] Browser server started');
}

export async function teardown() {
	const HARD_DEADLINE_MS = 5000;
	const forceExitTimer = setTimeout(() => {
		console.warn('[vitest-browser-setup] Force exiting - teardown exceeded 5s deadline');
		process.exit(0);
	}, HARD_DEADLINE_MS);

	try {
		await cleanup();
		console.log('[vitest-browser-setup] Cleanup complete');
	} finally {
		clearTimeout(forceExitTimer);
	}
}
