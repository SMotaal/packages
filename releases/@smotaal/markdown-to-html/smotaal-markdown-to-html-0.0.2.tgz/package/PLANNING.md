# Markdown-to-HTML Tool: Planning Document

> **Package:** `@smotaal/markdown-to-html`
> **Location:** `packages/markdown-to-html`
> **Status:** Planning
> **Created:** December 28, 2025

## 1. Problem Statement

Converting Markdown to HTML for documentation (e.g., `SPECIFICATION.md`) requires:

1. **Clean Markdown** — No inline `<style>` or `<script>` tags in source files
2. **Mermaid Support** — Graceful upgrade of code blocks to rendered diagrams
3. **Print Optimization** — Proper page breaks for PDF generation
4. **Single-File Output** — Embedded CSS/JS for portable, self-contained HTML
5. **HTML Conformance** — Valid DOCTYPE, proper structure, lintable output
6. **Workspace Customization** — Config files for reusable settings

### Current Workaround

Appending raw HTML to Markdown files:

```html
<style>
.mermaid svg { display: block; margin-left: auto; margin-right: auto; }
@media print { h1, h2, h3 { page-break-after: avoid; } }
</style>
<script type="module">
  import mermaid from 'https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.esm.min.mjs';
  // ... enhancement code
</script>
```

**Problems with this approach:**

- Pollutes Markdown with HTML
- Not reusable across documents
- Difficult to maintain
- Breaks Markdown portability

## 2. Design Goals

| Priority | Goal                         | Rationale                                       |
| -------- | ---------------------------- | ----------------------------------------------- |
| P0       | Zero runtime dependencies    | Use Node.js 24+ built-ins (native `fetch`)      |
| P0       | Config-driven customization  | Separate content from presentation              |
| P0       | Graceful enhancement pattern | Transform pre blocks client-side, not in source |
| P0       | GitHub API rendering         | Authentic GitHub-flavored Markdown output       |
| P1       | Single-file bundling         | Portable output via Vite/Rollup                 |
| P1       | Conformant HTML output       | Proper DOCTYPE, charset, lang attributes        |
| P2       | Watch mode                   | Development convenience                         |
| P2       | Validation                   | Lint generated HTML                             |

## 3. Available Dependencies

### From Workspace Root `package.json`

| Dependency   | Version | Use Case                          |
| ------------ | ------- | --------------------------------- |
| `vite`       | ^7.1.5  | Bundling for `--single-file` mode |
| `vitest`     | ^3.2.4  | Testing                           |
| `typescript` | ^5.9.2  | Type checking (JSDoc)             |

### Node.js 24+ Built-in Modules

| Module               | Use Case            |
| -------------------- | ------------------- |
| `node:fs/promises`   | File I/O            |
| `node:path`          | Path manipulation   |
| `node:url`           | URL/path resolution |
| `node:util`          | `parseArgs` for CLI |
| **`fetch` (global)** | GitHub API requests |

**Note:** Node.js 24+ provides native `fetch()` — no external HTTP libraries needed.

## 4. Architecture

### 4.1 High-Level Flow

```
┌─────────────────┐     ┌──────────────────────┐     ┌─────────────────┐
│  Markdown File  │────▶│  GitHub Markdown API │────▶│   Raw HTML      │
└─────────────────┘     │  (native fetch)      │     │   (GFM body)    │
                        └──────────────────────┘     └────────┬────────┘
                                                              │
┌─────────────────┐                                           ▼
│  Config File    │──────────────────────────────▶┌───────────────────┐
│  (styles, JS)   │                               │  HTML Assembler   │
└─────────────────┘                               │  (wrap in doc)    │
                                                  └─────────┬─────────┘
┌─────────────────┐                                         │
│  GitHub CSS     │─────────────────────────────────────────┤
│  (CDN/generated)│                                         │
└─────────────────┘                                         ▼
                                                  ┌─────────────────┐
                             --single-file ──────▶│    Bundler      │
                                                  │  (Vite/Rollup)  │
                                                  └────────┬────────┘
                                                           │
                                                           ▼
                                                  ┌─────────────────┐
                                                  │  Final HTML     │
                                                  └─────────────────┘
```

### 4.2 Package Structure

```
packages/common/tools/markdown/markdown-to-html/
├── PLANNING.md              # This document
├── package.json
├── bin/
│   └── markdown-to-html.js  # CLI entry point
├── src/
│   ├── index.js             # Public API
│   ├── cli.js               # CLI argument parsing
│   ├── renderer.js          # GitHub API Markdown rendering
│   ├── assembler.js         # Wrap body in full HTML document
│   ├── postprocessor.js     # HTML transformations
│   ├── bundler.js           # Single-file bundling
│   ├── config.js            # Config loading and merging
│   ├── validator.js         # HTML conformance checks
│   └── defaults/
│       ├── github.css       # GitHub markdown CSS (or fetch from CDN)
│       ├── print.css        # Print optimization CSS
│       ├── mermaid.css      # Mermaid diagram styling
│       └── enhancements.js  # Default graceful upgrades (mermaid)
└── tests/
    └── markdown-to-html.spec.ts
```

## 5. GitHub Markdown API

### 5.1 Overview

Use the GitHub REST API to render Markdown exactly as GitHub would, including:

- Task lists (`- [x]`)
- Alert boxes (`> [!NOTE]`)
- Syntax highlighting
- Emoji (`:smile:`)
- Autolinks

### 5.2 Endpoints

#### GFM Mode (Recommended)

Renders GitHub Flavored Markdown with full feature support.

```
POST https://api.github.com/markdown
```

**Headers:**

| Header                 | Value                         | Required                      |
| ---------------------- | ----------------------------- | ----------------------------- |
| `Accept`               | `application/vnd.github+json` | Yes                           |
| `X-GitHub-Api-Version` | `2022-11-28`                  | Yes                           |
| `Authorization`        | `Bearer {token}`              | Optional (higher rate limits) |
| `Content-Type`         | `application/json`            | Yes                           |

**Body (JSON):**

```json
{
  "text": "# Hello World\n\nThis is **bold**.",
  "mode": "gfm",
  "context": "owner/repo"
}
```

| Field     | Type                    | Description                                        |
| --------- | ----------------------- | -------------------------------------------------- |
| `text`    | string                  | Markdown content                                   |
| `mode`    | `"markdown"` \| `"gfm"` | Rendering mode (default: `markdown`)               |
| `context` | string                  | Repository for resolving relative links (optional) |

**Response:** Raw HTML string

#### Raw Mode (Plain Markdown)

For simple Markdown without GFM features. Content limit: 400 KB.

```
POST https://api.github.com/markdown/raw
```

**Headers:**

| Header                 | Value                             |
| ---------------------- | --------------------------------- |
| `Content-Type`         | `text/plain` or `text/x-markdown` |
| `X-GitHub-Api-Version` | `2022-11-28`                      |

**Body:** Raw Markdown text

### 5.3 Rate Limits

| Authentication        | Requests/Hour |
| --------------------- | ------------- |
| Unauthenticated       | 60            |
| Authenticated (token) | 5,000         |

For CI/CD or frequent use, authentication is recommended.

### 5.4 Implementation

```javascript
// src/renderer.js
const GITHUB_API = 'https://api.github.com/markdown';

/**
 * Render Markdown using GitHub API
 * @param {string} markdown - Markdown content
 * @param {object} options - Rendering options
 * @returns {Promise<string>} - HTML body content
 */
export async function renderMarkdown(markdown, options = {}) {
  const {
    mode = 'gfm',
    context = null,
    token = process.env.GITHUB_TOKEN,
  } = options;

  const headers = {
    'Accept': 'application/vnd.github+json',
    'X-GitHub-Api-Version': '2022-11-28',
    'Content-Type': 'application/json',
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const body = JSON.stringify({
    text: markdown,
    mode,
    ...(context && { context }),
  });

  const response = await fetch(GITHUB_API, {
    method: 'POST',
    headers,
    body,
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`GitHub API error (${response.status}): ${error}`);
  }

  return response.text();
}
```

## 6. Authentication & Secrets

### 6.1 Environment Variable

The tool reads `GITHUB_TOKEN` from environment:

```bash
# Local usage
export GITHUB_TOKEN=ghp_xxxxxxxxxxxx
markdown-to-html input.md -o output.html

# Or inline
GITHUB_TOKEN=ghp_xxxx markdown-to-html input.md -o output.html
```

### 6.2 CI Configuration

**GitHub Actions:**

```yaml
jobs:
  build-docs:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Render Markdown
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
        run: |
          yarn markdown-to-html docs/SPEC.md -o dist/SPEC.html
```

**Note:** `secrets.GITHUB_TOKEN` is automatically available in GitHub Actions.

### 6.3 Local `.env` Support (Optional)

If desired, the tool can support `.env` files via config:

```javascript
// markdown-to-html.config.js
export default {
  github: {
    // Explicit token (not recommended - use env var instead)
    // token: 'ghp_xxxx',

    // Or reference env var (default behavior)
    token: process.env.GITHUB_TOKEN,
  },
};
```

**Important:** Never commit `.env` files with secrets. Add to `.gitignore`.

## 7. GitHub Custom Elements

GitHub uses official custom elements from [github/github-elements](https://github.com/github/github-elements) for interactive features in rendered Markdown. To achieve full GitHub rendering fidelity, we should include the relevant elements.

### 7.1 Relevant Elements for GFM

| Element            | Package                          | Purpose                           |
| ------------------ | -------------------------------- | --------------------------------- |
| `<clipboard-copy>` | `@github/clipboard-copy-element` | Copy buttons on code blocks       |
| `<task-lists>`     | `@github/task-lists-element`     | Interactive task list checkboxes  |
| `<relative-time>`  | `@github/relative-time-element`  | Human-readable timestamps         |
| `<g-emoji>`        | `@github/g-emoji-element`        | Emoji fallback for older browsers |

### 7.2 Integration Strategy

**Option A: CDN Import (Default)**

Load elements from CDN for simplicity:

```html
<script type="module">
  import 'https://esm.sh/@github/clipboard-copy-element';
  import 'https://esm.sh/@github/relative-time-element';
</script>
```

**Option B: Bundled (for `--single-file`)**

Fetch and embed the element scripts inline.

### 7.3 Clipboard Copy for Code Blocks

GitHub renders code blocks with copy buttons. Our post-processor can add them:

```javascript
// postprocessor.js - Add copy buttons to code blocks
function addCopyButtons(html) {
  // Find all <pre><code> blocks and wrap with copy button
  // <clipboard-copy for="code-{id}" class="copy-btn">Copy</clipboard-copy>
}
```

### 7.4 Configuration

```javascript
// markdown-to-html.config.js
export default {
  githubElements: {
    enabled: true,
    // Elements to include
    elements: ['clipboard-copy', 'relative-time'],
    // CDN base URL
    cdnUrl: 'https://esm.sh/@github',
  },
};
```

## 8. GitHub Markdown CSS

### 8.1 Initial Source (CDN)

Initially, use `github-markdown-css` from CDN:

```
https://cdnjs.cloudflare.com/ajax/libs/github-markdown-css/5.5.1/github-markdown.min.css
```

Theme variants:

- `github-markdown-light.css` — Light theme only
- `github-markdown-dark.css` — Dark theme only
- `github-markdown.css` — Auto (uses `prefers-color-scheme`)

> **Secondary Priority:** Implement our own CSS generator to avoid external dependencies.
> See [Section 14: GitHub CSS Generator](#14-github-css-generator-secondary-priority).

### 7.2 Usage

Wrap rendered content in `.markdown-body`:

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Document</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/github-markdown-css/5.5.1/github-markdown.min.css">
  <style>
    .markdown-body {
      box-sizing: border-box;
      min-width: 200px;
      max-width: 980px;
      margin: 0 auto;
      padding: 45px;
    }
  </style>
</head>
<body>
  <article class="markdown-body">
    <!-- Rendered HTML from GitHub API -->
  </article>
</body>
</html>
```

### 7.3 Single-File Mode

For `--single-file`, fetch and embed the CSS:

```javascript
async function fetchGitHubCSS(theme = 'auto') {
  const variant = theme === 'auto' ? '' : `-${theme}`;
  const url = `https://cdnjs.cloudflare.com/ajax/libs/github-markdown-css/5.5.1/github-markdown${variant}.min.css`;
  const response = await fetch(url);
  return response.text();
}
```

## 9. Configuration Design

### 9.1 Config File Location

Resolution order (first found wins):

1. CLI `--config` argument
2. `markdown-to-html.config.js` in input file directory
3. `markdown-to-html.config.js` in workspace root
4. Built-in defaults

### 9.2 Config Schema

```javascript
/** @type {import('@smotaal/markdown-to-html').Config} */
export default {
  // GitHub API settings
  github: {
    // Token from env var (default: GITHUB_TOKEN)
    token: process.env.GITHUB_TOKEN,
    // Rendering mode: 'gfm' | 'markdown'
    mode: 'gfm',
    // Repository context for relative links (optional)
    context: null,  // e.g., 'smotaal/gists.smotaal.io'
  },

  // HTML document structure
  document: {
    doctype: '<!DOCTYPE html>',
    lang: 'en',
    charset: 'utf-8',
    title: null,  // Extracted from first H1 if null
  },

  // Theme: 'auto' | 'light' | 'dark'
  theme: 'auto',

  // Styles to inject
  styles: [
    // Use built-in GitHub CSS
    { builtin: 'github' },
    // Use built-in print optimization
    { builtin: 'print' },
    // Use built-in mermaid styling
    { builtin: 'mermaid' },
    // Path relative to config file
    // './custom-styles.css',
    // Inline CSS
    // { inline: '@media print { ... }' },
  ],

  // JavaScript enhancements
  enhancements: [
    // Use built-in mermaid enhancement
    { builtin: 'mermaid' },
    // Custom enhancement file
    // './custom-enhancements.js',
  ],

  // Mermaid configuration
  mermaid: {
    enabled: true,
    // CDN URL for mermaid library
    cdnUrl: 'https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.esm.min.mjs',
    // Mermaid.initialize() options
    config: { startOnLoad: true },
    // Selector for code blocks to transform
    selector: 'pre:has(> code:first-child:last-child.lang-mermaid)',
  },

  // Print optimization
  print: {
    enabled: true,
    avoidBreakInside: ['table', 'figure', 'div.no-break', 'pre'],
    avoidBreakAfter: ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'],
  },

  // Single-file bundling
  bundle: {
    // Inline all external resources
    inlineAssets: true,
    // Minify output
    minify: false,
  },

  // Validation
  validate: {
    enabled: true,
    rules: ['doctype', 'charset', 'lang'],
  },
};
```

## 10. CLI Interface

```bash
# Basic usage
markdown-to-html input.md -o output.html

# Single-file output (embedded CSS/JS)
markdown-to-html input.md -o output.html --single-file

# Custom config
markdown-to-html input.md -o output.html --config ./my-config.js

# Theme override
markdown-to-html input.md -o output.html --theme dark

# With repository context (for relative links)
markdown-to-html input.md -o output.html --context smotaal/gists.smotaal.io

# Watch mode
markdown-to-html input.md -o output.html --watch

# Validate only (no output)
markdown-to-html input.md --validate

# Verbose output
markdown-to-html input.md -o output.html --verbose
```

### CLI Options

| Option          | Short | Description                    |
| --------------- | ----- | ------------------------------ |
| `--output`      | `-o`  | Output file path               |
| `--config`      | `-c`  | Config file path               |
| `--single-file` |       | Embed all assets inline        |
| `--theme`       | `-t`  | Theme: auto, light, dark       |
| `--context`     |       | GitHub repo for relative links |
| `--watch`       | `-w`  | Watch for changes              |
| `--validate`    |       | Validate output HTML           |
| `--verbose`     | `-v`  | Verbose logging                |
| `--help`        | `-h`  | Show help                      |
| `--version`     |       | Show version                   |

### Environment Variables

| Variable       | Description                             |
| -------------- | --------------------------------------- |
| `GITHUB_TOKEN` | GitHub API token for higher rate limits |

## 11. Default Styles

### 11.1 Print Optimization (`defaults/print.css`)

```css
@media print {
  /* Avoid breaking headings from following content */
  h1, h2, h3, h4, h5, h6 {
    page-break-after: avoid;
    break-after: avoid-page;
  }

  /* Keep these elements together */
  table, figure, div.no-break, pre {
    page-break-inside: avoid;
    break-inside: avoid-page;
  }

  /* Don't orphan paragraphs before kept-together elements */
  p:has(+ table, + figure, + div.no-break, + pre) {
    page-break-after: avoid;
    break-after: avoid-page;
  }
}
```

### 11.2 Mermaid Styling (`defaults/mermaid.css`)

```css
.mermaid svg {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: auto;
}
```

## 12. Default Enhancements

### 12.1 Mermaid Graceful Upgrade (`defaults/enhancements.js`)

```javascript
// Gracefully upgrade mermaid code blocks
const MERMAID_SELECTOR = 'pre:has(> code:first-child:last-child.lang-mermaid)';

async function enhanceMermaid(config) {
  const preBlocks = document.querySelectorAll(MERMAID_SELECTOR);
  if (preBlocks.length === 0) return;

  // Transform pre blocks before mermaid loads
  for (const pre of preBlocks) {
    Object.assign(pre, {
      className: 'mermaid',
      innerHTML: pre.innerText,
    });
  }

  // Load and initialize mermaid
  const { default: mermaid } = await import(config.cdnUrl);
  mermaid.initialize(config.config);
}

// Export for use by tool
export { enhanceMermaid };
```

## 13. Implementation Phases

### Phase 1: Core Pipeline (MVP)

- [ ] Package structure and `package.json`
- [ ] GitHub API renderer (native `fetch`)
- [ ] HTML assembler (wrap body in document)
- [ ] Config loader with defaults
- [ ] CLI with basic options (`-o`, `--theme`, `--context`)
- [ ] Default styles (github, print, mermaid)
- [ ] Default mermaid enhancement
- [ ] GitHub Elements integration (clipboard-copy, relative-time)

### Phase 2: Single-File Bundling

- [ ] Fetch and embed GitHub CSS
- [ ] Fetch and embed mermaid.js (or use CDN reference)
- [ ] Asset inlining (CSS, JS)
- [ ] Vite-based bundler for complex cases

### Phase 3: Polish

- [ ] Watch mode (using `node:fs` watch)
- [ ] HTML validation
- [ ] Verbose logging
- [ ] Error handling improvements
- [ ] Rate limit handling (retry with backoff)
- [ ] Tests

### Phase 4: Offline Fallback (Future)

- [ ] Optional local markdown parser for offline use
- [ ] Cache rendered results by content hash

## 14. GitHub CSS Generator (Secondary Priority)

> **Priority:** Secondary — implement after core tool is working with CDN CSS.

### 14.1 Rationale

The `sindresorhus/github-markdown-css` package:

- Has many transitive dependencies
- Relies on `generate-github-markdown-css` which scrapes GitHub's actual styles
- May break if GitHub changes their HTML/CSS structure
- Adds external dependency risk

### 14.2 Goal

Implement our own CSS generator that:

1. Extracts styles directly from GitHub's rendered HTML
2. Produces minimal, dependency-free CSS
3. Supports light/dark/auto themes
4. Can be regenerated on-demand when GitHub updates their styles

### 14.3 Approach

```
┌─────────────────────┐     ┌──────────────────────┐     ┌─────────────────┐
│  Sample Markdown    │────▶│  GitHub Markdown API │────▶│  Rendered HTML  │
│  (all elements)     │     └──────────────────────┘     └────────┬────────┘
└─────────────────────┘                                           │
                                                                  ▼
┌─────────────────────┐     ┌──────────────────────┐     ┌─────────────────┐
│  Generated CSS      │◀────│  Style Extractor     │◀────│  GitHub.com     │
│  (github.css)       │     │  (fetch + parse)     │     │  (live styles)  │
└─────────────────────┘     └──────────────────────┘     └─────────────────┘
```

**Steps:**

1. Create comprehensive sample Markdown with all GFM elements
2. Render via GitHub API to get class names used
3. Fetch a real GitHub page (e.g., README preview) to extract computed styles
4. Generate minimal CSS targeting `.markdown-body` and its descendants
5. Output theme variants (light, dark, auto with `prefers-color-scheme`)

### 14.4 Package Location

```
packages/common/tools/markdown/generate-github-css/
├── package.json
├── src/
│   ├── index.js           # Public API
│   ├── cli.js             # CLI: generate-github-css -o github.css
│   ├── sample-markdown.md # Comprehensive GFM sample
│   ├── style-extractor.js # Fetch and parse GitHub styles
│   └── css-generator.js   # Generate minimal CSS
└── output/
    ├── github-markdown.css       # Auto theme
    ├── github-markdown-light.css # Light only
    └── github-markdown-dark.css  # Dark only
```

### 14.5 Implementation Tasks

- [ ] Create comprehensive sample Markdown (headings, lists, tables, code, etc.)
- [ ] Implement style extraction from GitHub.com
- [ ] Generate CSS with proper selectors
- [ ] Support theme variants
- [ ] Add regeneration script for updates
- [ ] Integrate with `markdown-to-html` as `{ builtin: 'github' }`

## 15. Open Questions

1. **Offline rendering:** Should we support a fallback markdown parser when:
   - Network is unavailable?
   - Rate limit is exceeded?

2. **Image handling:** For `--single-file`, should we:
   - Convert external images to data URIs?
   - Download and embed?
   - Leave as external references?

3. **Caching:** Should we cache rendered results locally?
   - By content hash?
   - With TTL?

4. **Multiple input files:** Support batch processing?
   - `markdown-to-html src/**/*.md --out-dir dist/`

## 16. References

- [GitHub Markdown API](https://docs.github.com/en/rest/markdown) — Official docs
- [GitHub Render Markdown API](https://adamj.eu/tech/2025/04/16/github-render-markdown-api/) — Practical guide
- [github/github-elements](https://github.com/github/github-elements) — Official GitHub custom elements
- [@github/clipboard-copy-element](https://www.npmjs.com/package/@github/clipboard-copy-element) — Copy button element
- [sindresorhus/github-markdown-css](https://github.com/sindresorhus/github-markdown-css) — Current CSS source (temporary)
- [sindresorhus/generate-github-markdown-css](https://github.com/sindresorhus/generate-github-markdown-css) — Reference for CSS generation approach
- [Vite Library Mode](https://vite.dev/guide/build#library-mode) — For bundling
- [CSS Page Break Properties](https://developer.mozilla.org/en-US/docs/Web/CSS/break-after) — Print optimization
- [Mermaid.js](https://mermaid.js.org/) — Diagram rendering

---

## Changelog

| Date       | Change                                           |
| ---------- | ------------------------------------------------ |
| 2025-12-28 | Initial planning document                        |
| 2025-12-28 | Replaced ghmd with direct GitHub API rendering   |
| 2025-12-28 | Added GitHub CSS Generator as secondary priority |
| 2025-12-28 | Added GitHub Elements integration (Section 7)    |
