// @ts-check
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { defineConfig } from 'vitest/config';

const __dirname = dirname(fileURLToPath(import.meta.url));

// Browser-only mode: skip Vite server startup (this package doesn't need it)
process.env.VITEST_BROWSER_ONLY = '1';

export default defineConfig({
	test: {
		globals: true,
		environment: 'node',
		include: ['tests/**/*.test.js'],
		// Use local globalSetup for browser lifecycle management
		// This ensures proper cleanup even on test interruption/failure
		globalSetup: [resolve(__dirname, 'tests/helpers/vitest-browser-setup.js')],
		coverage: {
			provider: 'v8',
			include: ['src/**/*.js'],
			exclude: ['src/defaults/**'],
		},
	},
});
