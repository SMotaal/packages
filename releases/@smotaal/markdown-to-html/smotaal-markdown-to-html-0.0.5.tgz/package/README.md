# @smotaal/markdown-to-html

Convert Markdown to HTML using GitHub's Markdown API with support for single-file bundling, Mermaid diagrams, and print optimization.

## Features

- **GitHub-Flavored Markdown** — Renders via GitHub's API for authentic output
- **Mermaid Diagrams** — Server-side SVG rendering (default) or client-side enhancement
- **Single-File Output** — Embedded CSS/JS/images for portable, self-contained HTML
- **Image Inlining** — Converts local images to data URLs in single-file mode
- **Print Optimization** — Proper page breaks for PDF generation
- **Theme Support** — Auto (system preference), light, or dark themes
- **GitHub Elements** — Clipboard copy buttons and relative time elements

## Requirements

- **Node.js >= 24** (uses native `fetch`, `parseArgs`, and `glob`)

## Installation

This is a private workspace package. From the monorepo root:

```bash
yarn workspace @smotaal/markdown-to-html build
```

Or run directly:

```bash
./packages/common/tools/markdown/markdown-to-html/bin/markdown-to-html.js
```

## CLI Usage

```bash
markdown-to-html [options] <files...>
```

### Options

| Option                 | Short | Description                                         |
| ---------------------- | ----- | --------------------------------------------------- |
| `--output <dir>`       | `-o`  | Output directory (default: same as input)           |
| `--configuration <f>`  | `-c`  | Path to configuration file                          |
| `--theme <theme>`      | `-t`  | Color theme: `auto`, `light`, or `dark`             |
| `--context <repo>`     |       | GitHub repo context for relative links              |
| `--single-file`        | `-s`  | Bundle all assets into single HTML file             |
| `--mermaid-mode <m>`   | `-m`  | Mermaid rendering mode (see below)                  |
| `--no-bundled-mermaid` |       | Use CDN for mermaid instead of bundling (with `-s`) |
| `--bundler <name>`     | `-b`  | Bundler to use: `vite` or `rollup` (default: vite)  |
| `--rollup`             |       | Use Rollup bundler (shortcut for `-b rollup`)       |
| `--help`               | `-h`  | Show help message                                   |
| `--version`            | `-v`  | Show version number                                 |

### Mermaid Mode

The `--mermaid-mode` / `-m` option controls how mermaid diagrams are rendered:

| Mode      | Description                                                        |
| --------- | ------------------------------------------------------------------ |
| `svg`     | **Default.** Server-side SVG rendering using `@mermaid-js/mermaid-cli` |
| `<ver>`   | Client-side with specific version (e.g., `10.9.0`)                 |
| `latest`  | Client-side with latest mermaid from CDN                           |
| `false`   | Disable mermaid rendering entirely                                 |

**Server-side SVG mode (`svg`):**

- Renders diagrams at build time — no client-side JavaScript needed
- Produces smaller, faster-loading HTML files
- Includes a "View Source" button overlay for accessing the mermaid code
- Uses `@mermaid-js/mermaid-cli` if installed, or falls back to `npx mmdc`

**Client-side mode (`<version>` or `latest`):**

- Renders diagrams in the browser using mermaid library
- Falls back gracefully if JavaScript is disabled

### Environment Variables

| Variable       | Description                             |
| -------------- | --------------------------------------- |
| `GITHUB_TOKEN` | GitHub API token for higher rate limits |

## Examples

### Basic Conversion

```bash
# Convert a single file
markdown-to-html README.md

# Convert multiple files
markdown-to-html docs/*.md

# Specify output directory
markdown-to-html -o dist src/**/*.md
```

### Single-File Mode

Single-file mode (`-s`) bundles all assets inline for a fully portable, self-contained HTML file:

- **CSS** — GitHub markdown styles and custom CSS embedded inline
- **JavaScript** — Enhancement scripts embedded as `<script type="module">`
- **Images** — Local images (SVG, PNG, JPEG, etc.) converted to data URLs
- **Mermaid** — Diagrams rendered as inline SVG (default) or bundled client-side library

This creates a single HTML file that works offline with no external dependencies.

```bash
# Create self-contained HTML (uses Vite by default)
markdown-to-html -s SPECIFICATION.md

# Use Rollup for smaller output (recommended for production)
markdown-to-html -s --rollup SPECIFICATION.md

# Use CDN for mermaid instead of bundling
markdown-to-html -s --no-bundled-mermaid docs/README.md
```

### Theme Options

```bash
# Use dark theme
markdown-to-html -t dark README.md

# Use light theme
markdown-to-html --theme light README.md

# Auto theme follows system preference (default)
markdown-to-html README.md
```

### GitHub Context

When your Markdown contains relative links to other files in a repository, use `--context` to resolve them correctly:

```bash
markdown-to-html --context owner/repo docs/SPEC.md
```

## Bundler Comparison

When using single-file mode (`-s`), mermaid is bundled inline as a base64 data URL. The bundler choice affects output size:

| Bundler          | Code Size | Base64 Size | HTML Size (approx) |
| ---------------- | --------: | ----------: | -----------------: |
| Rollup           |   2.48 MB |     3.30 MB |            ~3.4 MB |
| Vite (default)   |   3.48 MB |     4.64 MB |            ~4.8 MB |

### Recommendations

- **Production**: Use `--rollup` for smallest output size
- **Development**: Use Vite (default) for faster builds
- **Offline documents**: Single-file mode with bundled mermaid
- **Web serving**: Consider `--no-bundled-mermaid` to use CDN

### Why the Size Difference?

- **Base64 encoding** adds ~33% overhead to the bundled JavaScript
- **Mermaid is large** because it includes all diagram types (flowchart, sequence, gantt, etc.)
- **No per-diagram tree-shaking** — Mermaid's architecture requires bundling all diagram types even if you only use one
- **Rollup produces smaller bundles** due to more aggressive tree-shaking and dead code elimination

## Configuration

Create a `markdown-to-html.config.js` file in your project:

```javascript
/** @type {import('@smotaal/markdown-to-html').Configuration} */
export default {
  // GitHub API settings
  github: {
    token: process.env.GITHUB_TOKEN,
    mode: 'gfm',
    context: 'owner/repo',
  },

  // Theme: 'auto' | 'light' | 'dark'
  theme: 'auto',

  // Mermaid configuration
  mermaid: {
    enabled: true,
    cdnURL: 'https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js',
    configuration: { startOnLoad: true },
    selector: 'pre > code.language-mermaid',
  },

  // GitHub elements (clipboard-copy, relative-time)
  githubElements: {
    enabled: true,
    elements: ['clipboard-copy', 'relative-time'],
    cdnURL: 'https://esm.sh/@github',
  },

  // Print optimization
  print: {
    enabled: true,
    avoidBreakInside: ['table', 'figure', 'div.no-break', 'pre'],
    avoidBreakAfter: ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'],
  },
};
```

### Configuration Resolution

Configuration files are searched in this order:

1. Path specified via `--configuration` / `-c`
2. `markdown-to-html.config.js` in input file directory
3. `markdown-to-html.config.mjs` in input file directory
4. `markdown-to-html.config.js` in workspace root
5. `markdown-to-html.config.mjs` in workspace root
6. Built-in defaults

## Programmatic API

```javascript
import {
  renderMarkdown,
  assembleDocument,
  extractTitle,
  resolveConfiguration,
  cli,
} from '@smotaal/markdown-to-html';

// Render markdown via GitHub API
const html = await renderMarkdown('# Hello World', {
  mode: 'gfm',
  context: 'owner/repo',
  token: process.env.GITHUB_TOKEN,
});

// Assemble into a complete HTML document
const document = assembleDocument(html, {
  title: 'My Document',
  theme: 'auto',
  styles: ['/* custom CSS */'],
  scripts: ['// custom JS'],
});

// Or use the CLI programmatically
const exitCode = await cli(['README.md', '-o', 'dist', '-s', '--rollup']);
```

### API Exports

| Export                        | Description                               |
| ----------------------------- | ----------------------------------------- |
| `renderMarkdown`              | Render Markdown via GitHub API            |
| `renderMarkdownRaw`           | Render Markdown via GitHub's raw endpoint |
| `assembleDocument`            | Wrap HTML body in complete document       |
| `extractTitle`                | Extract title from first H1 element       |
| `resolveConfiguration`        | Load and merge configuration files        |
| `defaultConfiguration`        | Built-in default configuration            |
| `loadConfigurationFile`       | Load a specific configuration file        |
| `findConfigurationFile`       | Find configuration file in directory      |
| `mergeConfiguration`          | Deep merge two configurations             |
| `generateImportMap`           | Generate import map for bare specifiers   |
| `loadDefaultStyles`           | Load built-in CSS styles                  |
| `loadEnhancementScript`       | Load mermaid enhancement script           |
| `fetchMermaidAsDataURL`       | Fetch mermaid from CDN as data URL        |
| `fetchCSSFromCDN`             | Fetch GitHub markdown CSS from CDN        |
| `getGitHubCSSCDNURL`          | Get CDN URL for GitHub CSS                |
| `getGitHubElementsScriptURLs` | Get CDN URLs for GitHub custom elements   |
| `slugify`                     | Generate URL-friendly slugs from strings  |
| `addHeadingIds`               | Add ID attributes to heading elements     |
| `addHeadingAnchors`           | Add anchor links to headings              |
| `postprocess`                 | Post-process rendered HTML                |
| `extractMermaidBlocks`        | Extract mermaid code blocks from HTML     |
| `processMermaidBlocks`        | Process mermaid blocks (server-side SVG)  |
| `renderMermaidToSVG`          | Render single mermaid diagram to SVG      |
| `replaceMermaidWithSVG`       | Replace mermaid blocks with SVG output    |
| `generateMermaidHTML`         | Generate mermaid HTML with dialog         |
| `isMermaidCLIAvailable`       | Check if mermaid-cli is installed         |
| `runMermaidCLI`               | Run mermaid-cli via npx (CLI fallback)    |
| `inlineImages`                | Inline local images as data URLs          |
| `imageToDataURL`              | Convert single image file to data URL     |
| `getMimeType`                 | Get MIME type for image extension         |
| `cli`                         | Run CLI programmatically                  |
| `parseCLI`                    | Parse CLI arguments                       |

## How It Works

1. **Render**: Markdown is sent to GitHub's API for rendering
2. **Post-process**: Heading IDs are added, mermaid diagrams are rendered to SVG
3. **Style**: GitHub markdown CSS and custom styles are applied
4. **Bundle** (optional): CSS, JS, and images are inlined for single-file output

### Server-Side SVG Rendering (Default)

By default, mermaid diagrams are rendered to SVG at build time:

1. Code blocks with `language-mermaid` class are extracted from HTML
2. Each diagram is rendered to SVG using `@mermaid-js/mermaid-cli`
3. The SVG is wrapped with a "View Source" button for accessing the original code
4. A `<dialog>` element with `popover` attribute provides the source view

This approach produces smaller HTML files with no client-side JavaScript required.

### Client-Side Enhancement (Fallback)

When using `--mermaid-mode=<version>` or `--mermaid-mode=latest`, diagrams are enhanced client-side:

1. Code blocks with `language-mermaid` class are detected
2. The `<pre><code>` structure is transformed to `<div class="mermaid">`
3. Mermaid library initializes and renders the diagrams
4. If mermaid fails to load, the original code block remains visible

This ensures documents are readable even without JavaScript.

## Rate Limits

GitHub's Markdown API has rate limits:

| Authentication        | Requests/Hour |
| --------------------- | ------------: |
| Unauthenticated       |            60 |
| Authenticated (token) |         5,000 |

For CI/CD or frequent use, set the `GITHUB_TOKEN` environment variable.

## License

Private package — part of the @smotaal/tools monorepo.
