// @ts-check
/**
 * Server-side Mermaid SVG Renderer
 * Uses @mermaid-js/mermaid-cli to render mermaid diagrams to SVG
 */

import { writeFile, readFile, rm, mkdtemp } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { spawn } from 'node:child_process';

/**
 * @typedef {object} MermaidBlock
 * @property {string} id - Unique identifier for this block
 * @property {string} content - Mermaid diagram source code
 * @property {string} originalHTML - Original HTML to be replaced
 */

/**
 * @typedef {object} RenderOptions
 * @property {string} [theme='default'] - Mermaid theme
 * @property {string} [backgroundColor='transparent'] - Background color
 */

/**
 * Check if npx can run mermaid-cli
 * @returns {Promise<boolean>}
 */
async function isNpxMermaidAvailable() {
	return new Promise((resolve) => {
		const mmdc = spawn('npx', ['@mermaid-js/mermaid-cli', '--version'], {
			stdio: ['pipe', 'pipe', 'pipe'],
		});

		mmdc.on('close', (code) => {
			resolve(code === 0);
		});

		mmdc.on('error', () => {
			resolve(false);
		});

		// Timeout after 10 seconds
		setTimeout(() => {
			mmdc.kill();
			resolve(false);
		}, 10000);
	});
}

/**
 * Check if @mermaid-js/mermaid-cli is available (via import or npx)
 * @returns {Promise<boolean>}
 */
export async function isMermaidCLIAvailable() {
	// First try programmatic import
	try {
		const { run } = await import('@mermaid-js/mermaid-cli');
		if (typeof run === 'function') {
			return true;
		}
	} catch {
		// Fall through to npx check
	}

	// Fall back to npx
	return isNpxMermaidAvailable();
}

/**
 * Render mermaid source code to SVG using mermaid-cli
 * @param {string} mermaidSource - Mermaid diagram source code
 * @param {RenderOptions} [options={}] - Rendering options
 * @returns {Promise<string>} - SVG content
 */
export async function renderMermaidToSVG(mermaidSource, options = {}) {
	const { theme = 'default', backgroundColor = 'transparent' } = options;

	// Create temp directory for mermaid-cli
	const tempDirectory = await mkdtemp(join(tmpdir(), 'mermaid-'));
	const inputPath = join(tempDirectory, 'input.mmd');
	const outputPath = join(tempDirectory, 'output.svg');

	try {
		// Write mermaid source to temp file
		await writeFile(inputPath, mermaidSource, 'utf-8');

		// Try to use mermaid-cli programmatic API first
		try {
			const { run } = await import('@mermaid-js/mermaid-cli');
			await run(inputPath, /** @type {`${string}.svg`} */ (outputPath), {
				outputFormat: 'svg',
				parseMMDOptions: {
					mermaidConfig: {
						theme: /** @type {'dark' | 'default' | 'base' | 'forest' | 'neutral'} */ (theme),
						// Use SVG text elements instead of foreignObject for better label sizing
						// foreignObject can have dimension issues in non-browser rendering (puppeteer)
						flowchart: {
							htmlLabels: false,
							useMaxWidth: false,
						},
						// Sequence diagram sizing configuration
						// - Reduce oversized default height (65 -> 50)
						// - Add proper margins for text fitting
						// - Increase note margin to prevent text touching edges
						// - noteAlign: center is required to fix vertical alignment bug (mermaid#1914)
						sequence: {
							useMaxWidth: false,
							height: 50,
							boxMargin: 10,
							boxTextMargin: 8,
							noteMargin: 15,
							noteAlign: 'center',
							actorFontSize: 14,
							noteFontSize: 14,
							messageFontSize: 14,
						},
					},
				},
				puppeteerConfig: {
					args: ['--no-sandbox', '--disable-setuid-sandbox'],
				},
			});
		} catch (importError) {
			// Fall back to CLI if programmatic API fails
			await runMermaidCLI(inputPath, outputPath, { theme, backgroundColor });
		}

		// Read and return SVG content
		let svg = await readFile(outputPath, 'utf-8');

		// Post-process SVG to fix vertical text alignment issues (mermaid-cli/puppeteer bug)
		// Text renders ~0.35em above geometric center. Increase dy (+ve = down) to center.
		// - Actors: tspan has dy="0", change to dy="0.35em"
		// - Notes/Messages: text has dy="1em", increase to dy="1.35em"
		svg = svg
			.replace(/<tspan([^>]*)dy="0">/g, '<tspan$1dy="0.35em">')
			.replace(/(<text[^>]*class="(?:messageText|noteText)"[^>]*)dy="1em"/g, '$1dy="1.35em"')

		return svg;
	} finally {
		// Clean up temp directory
		await rm(tempDirectory, { recursive: true, force: true }).catch(() => {});
	}
}

/**
 * Run mermaid-cli as a child process (fallback when programmatic API unavailable)
 *
 * Note: We omit --puppeteerConfigFile because mermaid-cli has safe defaults.
 * Passing /dev/null causes JSON.parse errors since /dev/null is empty.
 * If custom puppeteer config is needed, install @mermaid-js/mermaid-cli
 * as a dependency to use the programmatic API instead.
 *
 * @param {string} inputPath - Path to input .mmd file
 * @param {string} outputPath - Path to output .svg file
 * @param {RenderOptions} options - Rendering options
 * @returns {Promise<void>}
 */
export async function runMermaidCLI(inputPath, outputPath, options) {
	const { theme = 'default', backgroundColor = 'transparent' } = options;

	const args = [
		'@mermaid-js/mermaid-cli',
		'-i', inputPath,
		'-o', outputPath,
		'-t', theme,
		'-b', backgroundColor,
	];

	return new Promise((resolve, reject) => {
		const mmdc = spawn('npx', args, {
			stdio: ['pipe', 'pipe', 'pipe'],
		});

		let stdout = '';
		let stderr = '';

		mmdc.stdout.on('data', (data) => {
			stdout += data.toString();
		});

		mmdc.stderr.on('data', (data) => {
			stderr += data.toString();
		});

		mmdc.on('close', (code) => {
			if (code === 0) {
				resolve();
			} else {
				const command = `npx ${args.join(' ')}`;
				const error = new Error(
					`mermaid-cli failed with code ${code}\n` +
					`Command: ${command}\n` +
					(stdout ? `stdout: ${stdout}\n` : '') +
					(stderr ? `stderr: ${stderr}` : '')
				);
				reject(error);
			}
		});

		mmdc.on('error', (error) => {
			reject(new Error(`Failed to spawn mermaid-cli: ${error.message}`));
		});
	});
}

/**
 * Extract mermaid code blocks from GitHub-rendered HTML
 * GitHub API renders mermaid as: .highlight-source-mermaid > pre
 * Fallback selector: pre > code.language-mermaid
 * @param {string} html - HTML content from GitHub API
 * @returns {MermaidBlock[]} - Array of mermaid blocks found
 */
export function extractMermaidBlocks(html) {
	/** @type {MermaidBlock[]} */
	const blocks = [];
	let counter = 0;

	// Pattern 1: GitHub API format - <div class="highlight highlight-source-mermaid"><pre>...</pre></div>
	const githubPattern = /<div[^>]*class="[^"]*highlight-source-mermaid[^"]*"[^>]*>\s*<pre[^>]*>([\s\S]*?)<\/pre>\s*<\/div>/gi;
	let match;

	while ((match = githubPattern.exec(html)) !== null) {
		const captured = match[1];
		if (captured === undefined) continue;
		const content = decodeHTMLEntities(captured.trim());
		blocks.push({
			id: `mermaid-${counter++}`,
			content,
			originalHTML: match[0],
		});
	}

	// Pattern 2: Fallback - <pre><code class="language-mermaid">...</code></pre>
	const fallbackPattern = /<pre[^>]*>\s*<code[^>]*class="[^"]*language-mermaid[^"]*"[^>]*>([\s\S]*?)<\/code>\s*<\/pre>/gi;

	while ((match = fallbackPattern.exec(html)) !== null) {
		const captured = match[1];
		if (captured === undefined) continue;
		const content = decodeHTMLEntities(captured.trim());
		// Check if this block was already captured by GitHub pattern
		if (!blocks.some(block => block.content === content)) {
			blocks.push({
				id: `mermaid-${counter++}`,
				content,
				originalHTML: match[0],
			});
		}
	}

	return blocks;
}

/**
 * Strip HTML tags from text
 * @param {string} text - Text with HTML tags
 * @returns {string} - Text without HTML tags
 */
function stripHTMLTags(text) {
	return text.replace(/<[^>]+>/g, '');
}

/**
 * Decode HTML entities in mermaid source
 * @param {string} text - Text with HTML entities
 * @returns {string} - Decoded text
 */
function decodeHTMLEntities(text) {
	// First strip HTML tags (GitHub adds <span> for syntax highlighting)
	const stripped = stripHTMLTags(text);
	// Then decode HTML entities
	return stripped
		.replace(/&lt;/g, '<')
		.replace(/&gt;/g, '>')
		.replace(/&amp;/g, '&')
		.replace(/&quot;/g, '"')
		.replace(/&#39;/g, "'")
		.replace(/&#x27;/g, "'")
		.replace(/&#x2F;/g, '/');
}

/**
 * Escape HTML special characters for safe embedding
 * @param {string} text - Text to escape
 * @returns {string} - Escaped text
 */
function escapeHTML(text) {
	return text
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;')
		.replace(/'/g, '&#39;');
}

/**
 * Generate HTML structure for SVG diagram with source fallback
 * @param {string} id - Unique identifier
 * @param {string} svg - Rendered SVG content
 * @param {string} source - Original mermaid source code
 * @returns {string} - Complete HTML structure
 */
export function generateMermaidHTML(id, svg, source) {
	const escapedSource = escapeHTML(source);
	const svgId = `${id}-svg`;

	// Replace default mermaid SVG ID with unique ID to prevent CSS leakage between diagrams
	// Mermaid-cli generates all SVGs with id="my-svg" and uses #my-svg in CSS selectors
	// This causes classDef styles from one diagram to affect other diagrams
	let processedSvg = svg
		.replace(/id="my-svg"/g, `id="${svgId}"`)
		.replace(/#my-svg\b/g, `#${svgId}`);

	// Add accessibility attributes
	const svgWithAccessibility = processedSvg
		.replace(/<svg/, `<svg class="mermaid-diagram" role="img" aria-labelledby="${id}-title"`)
		.replace(/>/, `><title id="${id}-title">Mermaid Diagram</title>`);

	return `<div class="mermaid-container" id="${id}">
${svgWithAccessibility}
<button class="mermaid-show-source" popovertarget="${id}-source" aria-label="Show diagram source code">View Source</button>
<dialog id="${id}-source" popover aria-modal="true" aria-labelledby="${id}-source-title">
<div class="mermaid-source-header">
<span id="${id}-source-title">Mermaid Source</span>
<button popovertarget="${id}-source" popovertargetaction="hide" aria-label="Close mermaid source dialog">Close</button>
</div>
<pre><code class="language-mermaid">${escapedSource}</code></pre>
</dialog>
</div>`;
}

/**
 * Replace mermaid blocks in HTML with rendered SVGs
 * @param {string} html - Original HTML content
 * @param {Map<string, string>} svgMap - Map of block ID to rendered SVG
 * @param {MermaidBlock[]} blocks - Mermaid blocks to replace
 * @returns {string} - HTML with mermaid blocks replaced by SVGs
 */
export function replaceMermaidWithSVG(html, svgMap, blocks) {
	let result = html;

	for (const block of blocks) {
		const svg = svgMap.get(block.id);
		if (svg) {
			const replacement = generateMermaidHTML(block.id, svg, block.content);
			result = result.replace(block.originalHTML, replacement);
		}
	}

	return result;
}

/**
 * Process all mermaid blocks in HTML and render to SVG
 * @param {string} html - HTML content with mermaid code blocks
 * @param {RenderOptions} [options={}] - Rendering options
 * @returns {Promise<string>} - HTML with mermaid blocks replaced by SVGs
 */
export async function processMermaidBlocks(html, options = {}) {
	const blocks = extractMermaidBlocks(html);

	if (blocks.length === 0) {
		return html;
	}

	// Check if mermaid-cli is available
	const available = await isMermaidCLIAvailable();
	if (!available) {
		console.warn('[mermaid] @mermaid-js/mermaid-cli not available, skipping server-side rendering');
		return html;
	}

	// Render each block to SVG
	/** @type {Map<string, string>} */
	const svgMap = new Map();

	for (const block of blocks) {
		try {
			const svg = await renderMermaidToSVG(block.content, options);
			svgMap.set(block.id, svg);
		} catch (error) {
			const message = error instanceof Error ? error.message : String(error);
			console.error(`[mermaid] Failed to render block ${block.id}: ${message}`);
			// Leave original block in place on error
		}
	}

	// Replace blocks with rendered SVGs
	return replaceMermaidWithSVG(html, svgMap, blocks);
}
