// @ts-check
/**
 * Public API for markdown-to-html
 */

export { renderMarkdown, renderMarkdownRaw } from './renderer.js';
export { assembleDocument, extractTitle } from './assembler.js';
export { defaultConfiguration, loadConfigurationFile, findConfigurationFile, mergeConfiguration, resolveConfiguration, generateImportMap } from './configuration.js';
export { loadDefaultStyles, loadEnhancementScript, fetchMermaidAsDataURL, fetchCSSFromCDN, getGitHubCSSCDNURL, getGitHubElementsScriptURLs } from './styles.js';
export { slugify, addHeadingIds, addHeadingAnchors, postprocess, extractMermaidBlocks, processMermaidBlocks, renderMermaidToSVG, replaceMermaidWithSVG, generateMermaidHTML, isMermaidCLIAvailable, runMermaidCLI } from './postprocessor.js';
export { inlineImages, imageToDataURL, getMimeType } from './image-inliner.js';
export { parseCLI, main as cli } from './cli.js';
