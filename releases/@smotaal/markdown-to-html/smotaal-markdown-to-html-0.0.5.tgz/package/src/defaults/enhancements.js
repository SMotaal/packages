// Graceful enhancement script for mermaid diagrams
// This script runs in the browser to upgrade code blocks to rendered diagrams
// Configuration is embedded at generation time - no globals needed

// Placeholders are replaced at generation time
const mermaidConfiguration = /* __MERMAID_CONFIG__ */ { startOnLoad: false };
const mermaidURL = /* __MERMAID_URL__ */ 'mermaid';

// GitHub API renders mermaid as: .highlight-source-mermaid > pre
// Fallback for older/custom renderers: pre > code.language-mermaid
const MERMAID_SELECTORS = [
	'.highlight-source-mermaid pre',
	'pre > code.language-mermaid',
];

(async function enhanceMermaid() {
	// Find mermaid blocks using multiple selectors
	const mermaidElements = [];
	for (const selector of MERMAID_SELECTORS) {
		mermaidElements.push(...document.querySelectorAll(selector));
	}
	if (mermaidElements.length === 0) return;

	// Transform code blocks to mermaid divs before loading mermaid
	const diagrams = [];
	for (const element of mermaidElements) {
		// Handle both formats:
		// 1. .highlight-source-mermaid > pre - element is the pre, parent is the highlight div
		// 2. pre > code.language-mermaid - element is the code, parent is the pre
		const isHighlightFormat = element.parentElement?.classList.contains('highlight-source-mermaid');
		const containerToReplace = isHighlightFormat ? element.parentElement : element.parentElement;
		const content = element.textContent || '';
		const id = `mermaid-${diagrams.length}`;

		// Create mermaid container
		const div = document.createElement('div');
		div.className = 'mermaid';
		div.id = id;
		div.textContent = content;

		// Replace container with div
		containerToReplace.replaceWith(div);
		diagrams.push({ id, content });
	}

	// Load mermaid via dynamic import
	// When bundled with -s, mermaidURL will be a data: URL containing the full ESM bundle
	// When not bundled, mermaidURL will be a CDN URL
	try {
		const { default: mermaid } = await import(mermaidURL);
		mermaid.initialize(mermaidConfiguration);
		await mermaid.run();
	} catch (error) {
		console.error('Failed to load mermaid:', error);
	}
})();
