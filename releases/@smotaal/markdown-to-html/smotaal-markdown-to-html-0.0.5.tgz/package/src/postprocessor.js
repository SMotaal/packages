// @ts-check
/**
 * HTML Postprocessor
 * Transforms GitHub API HTML output to add heading IDs and other enhancements
 */

// Re-export mermaid renderer functions for convenience
export {
	extractMermaidBlocks,
	processMermaidBlocks,
	renderMermaidToSVG,
	replaceMermaidWithSVG,
	generateMermaidHTML,
	isMermaidCLIAvailable,
	runMermaidCLI,
} from './mermaid-renderer.js';

/**
 * Convert text to a URL-friendly slug
 * Matches GitHub's heading ID generation algorithm
 * @param {string} text - Heading text
 * @returns {string} - URL slug
 */
export function slugify(text) {
	return text
		.toLowerCase()
		.trim()
		// Remove HTML tags
		.replace(/<[^>]*>/g, '')
		// Replace special characters with their text equivalents
		.replace(/&amp;/g, 'and')
		.replace(/&/g, 'and')
		.replace(/&lt;/g, '')
		.replace(/&gt;/g, '')
		.replace(/&quot;/g, '')
		.replace(/&#\d+;/g, '')
		// Replace accented characters with ASCII equivalents
		.normalize('NFD')
		.replace(/[\u0300-\u036f]/g, '')
		// Replace non-alphanumeric characters with hyphens
		.replace(/[^a-z0-9]+/g, '-')
		// Remove leading/trailing hyphens
		.replace(/^-+|-+$/g, '');
}

/**
 * Add id attributes to headings that don't have them
 * GitHub's Markdown API doesn't add heading IDs, so we generate them
 * @param {string} html - HTML content
 * @returns {string} - HTML with heading IDs added
 */
export function addHeadingIds(html) {
	/** @type {Map<string, number>} */
	const usedIds = new Map();

	// Use non-greedy matching with .*? to match each heading separately
	return html.replace(
		/<(h[1-6])([^>]*)>(.*?)<\/\1>/gi,
		(match, tag, attrs, content) => {
			// Skip if already has an id attribute
			if (/\bid\s*=/.test(attrs)) {
				return match;
			}

			// Extract text content (strip nested tags for slug generation)
			const textContent = content.replace(/<[^>]*>/g, '').trim();
			let slug = slugify(textContent);

			// Handle empty slugs
			if (!slug) {
				slug = 'heading';
			}

			// Handle duplicate IDs by appending a number suffix
			const count = usedIds.get(slug) || 0;
			usedIds.set(slug, count + 1);

			const finalId = count === 0 ? slug : `${slug}-${count}`;

			return `<${tag}${attrs} id="${finalId}">${content}</${tag}>`;
		}
	);
}

/**
 * Add anchor links to headings (GitHub-style)
 * Adds a clickable anchor icon before each heading
 * @param {string} html - HTML content (should have heading IDs already)
 * @returns {string} - HTML with anchor links added
 */
export function addHeadingAnchors(html) {
	return html.replace(
		/<(h[1-6])([^>]*\bid="([^"]+)"[^>]*)>(.*?)<\/\1>/gi,
		(match, tag, attrs, id, content) => {
			const anchor = `<a class="anchor" aria-hidden="true" href="#${id}"></a>`;
			return `<${tag}${attrs}>${anchor}${content}</${tag}>`;
		}
	);
}

/**
 * Apply all postprocessing transformations
 * @param {string} html - Raw HTML from GitHub API
 * @param {object} [options] - Postprocessing options
 * @param {boolean} [options.headingIds=true] - Add heading IDs
 * @param {boolean} [options.headingAnchors=false] - Add anchor links to headings
 * @returns {string} - Processed HTML
 */
export function postprocess(html, options = {}) {
	const {
		headingIds = true,
		headingAnchors = false,
	} = options;

	let result = html;

	if (headingIds) {
		result = addHeadingIds(result);
	}

	if (headingAnchors) {
		result = addHeadingAnchors(result);
	}

	return result;
}
