// @ts-check
/**
 * GitHub Markdown API renderer
 * Uses native fetch to render Markdown via GitHub's API
 */

const GITHUB_API = 'https://api.github.com/markdown';
const GITHUB_API_RAW = 'https://api.github.com/markdown/raw';

/**
 * @typedef {object} RenderOptions
 * @property {'gfm' | 'markdown'} [mode='gfm'] - Rendering mode
 * @property {string | null} [context=null] - Repository context for relative links (e.g., 'owner/repo')
 * @property {string} [token] - GitHub API token for higher rate limits
 */

/**
 * Render Markdown using GitHub API
 * @param {string} markdown - Markdown content
 * @param {RenderOptions} [options={}] - Rendering options
 * @returns {Promise<string>} - HTML body content
 */
export async function renderMarkdown(markdown, options = {}) {
	const {
		mode = 'gfm',
		context = null,
		token = process.env.GITHUB_TOKEN,
	} = options;

	const headers = {
		'Accept': 'application/vnd.github+json',
		'X-GitHub-Api-Version': '2022-11-28',
		'Content-Type': 'application/json',
		'User-Agent': '@smotaal/markdown-to-html',
	};

	if (token) {
		headers['Authorization'] = `Bearer ${token}`;
	}

	const body = JSON.stringify({
		text: markdown,
		mode,
		...(context && { context }),
	});

	const response = await fetch(GITHUB_API, {
		method: 'POST',
		headers,
		body,
	});

	if (!response.ok) {
		const errorText = await response.text();
		const rateLimitRemaining = response.headers.get('x-ratelimit-remaining');
		const rateLimitReset = response.headers.get('x-ratelimit-reset');

		if (response.status === 403 && rateLimitRemaining === '0') {
			const resetDate = rateLimitReset ? new Date(parseInt(rateLimitReset) * 1000) : null;
			throw new Error(
				`GitHub API rate limit exceeded. ` +
				`Resets at: ${resetDate?.toISOString() ?? 'unknown'}. ` +
				`Set GITHUB_TOKEN environment variable for higher limits.`
			);
		}

		throw new Error(`GitHub API error (${response.status}): ${errorText}`);
	}

	return response.text();
}

/**
 * Render raw Markdown (plain mode, no GFM features)
 * @param {string} markdown - Markdown content
 * @param {Pick<RenderOptions, 'token'>} [options={}] - Options
 * @returns {Promise<string>} - HTML body content
 */
export async function renderMarkdownRaw(markdown, options = {}) {
	const { token = process.env.GITHUB_TOKEN } = options;

	const headers = {
		'Content-Type': 'text/plain',
		'X-GitHub-Api-Version': '2022-11-28',
		'User-Agent': '@smotaal/markdown-to-html',
	};

	if (token) {
		headers['Authorization'] = `Bearer ${token}`;
	}

	const response = await fetch(GITHUB_API_RAW, {
		method: 'POST',
		headers,
		body: markdown,
	});

	if (!response.ok) {
		const errorText = await response.text();
		throw new Error(`GitHub API error (${response.status}): ${errorText}`);
	}

	return response.text();
}
