// @ts-check
/**
 * Style loader
 * Loads CSS from CDN and built-in defaults
 */

import { readFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));

// CDN URLs for GitHub Markdown CSS
const GITHUB_CSS_CDN = 'https://cdnjs.cloudflare.com/ajax/libs/github-markdown-css/5.5.1/github-markdown.min.css';
const GITHUB_CSS_LIGHT = 'https://cdnjs.cloudflare.com/ajax/libs/github-markdown-css/5.5.1/github-markdown-light.min.css';
const GITHUB_CSS_DARK = 'https://cdnjs.cloudflare.com/ajax/libs/github-markdown-css/5.5.1/github-markdown-dark.min.css';

/**
 * @typedef {'auto' | 'light' | 'dark'} Theme
 */

/**
 * Get the GitHub Markdown CSS CDN URL for a theme
 * @param {Theme} theme - Color scheme theme
 */
export function getGitHubCSSCDNURL(theme) {
	switch (theme) {
		case 'light':
			return GITHUB_CSS_LIGHT;
		case 'dark':
			return GITHUB_CSS_DARK;
		default:
			return GITHUB_CSS_CDN;
	}
}

/**
 * Fetch CSS from CDN with proper error handling
 * @param {string} url - CDN URL
 * @returns {Promise<string>} - CSS content
 */
export async function fetchCSSFromCDN(url) {
	const response = await fetch(url, {
		headers: {
			'User-Agent': '@smotaal/markdown-to-html',
		},
	});

	if (!response.ok) {
		throw new Error(`Failed to fetch CSS from ${url}: ${response.status} ${response.statusText}`);
	}

	// Ensure UTF-8 decoding
	const buffer = await response.arrayBuffer();
	return new TextDecoder('utf-8').decode(buffer);
}

/**
 * Load built-in default style
 * @param {string} name - Style name (print, mermaid, layout)
 * @returns {Promise<string>} - CSS content
 */
export async function loadBuiltinStyle(name) {
	const stylePath = join(__dirname, 'defaults', `${name}.css`);
	// Read with explicit UTF-8 encoding
	return readFile(stylePath, { encoding: 'utf-8' });
}

/**
 * Load all default styles
 * @param {Theme} theme - Color scheme theme
 * @returns {Promise<string[]>} - Array of CSS content strings
 */
export async function loadDefaultStyles(theme = 'auto') {
	const [githubCSS, layoutCSS, printCSS, mermaidCSS] = await Promise.all([
		fetchCSSFromCDN(getGitHubCSSCDNURL(theme)),
		loadBuiltinStyle('layout'),
		loadBuiltinStyle('print'),
		loadBuiltinStyle('mermaid'),
	]);

	return [githubCSS, layoutCSS, printCSS, mermaidCSS];
}

/**
 * Fetch mermaid ESM and return as data: URL for importmap bundling
 * @param {string} cdnURL - CDN URL for mermaid ESM
 * @returns {Promise<string>} - Data URL containing mermaid module
 */
export async function fetchMermaidAsDataURL(cdnURL) {
	const response = await fetch(cdnURL, {
		headers: {
			'User-Agent': '@smotaal/markdown-to-html',
		},
	});

	if (!response.ok) {
		throw new Error(`Failed to fetch mermaid from ${cdnURL}: ${response.status} ${response.statusText}`);
	}

	const buffer = await response.arrayBuffer();
	const base64 = Buffer.from(buffer).toString('base64');
	return `data:text/javascript;base64,${base64}`;
}

/**
 * @typedef {object} EnhancementScriptOptions
 * @property {object} [configuration] - Mermaid initialization configuration
 * @property {string} [url] - Mermaid module URL (CDN or data: URL for bundled)
 */

/**
 * Load enhancement script for mermaid with embedded configuration and URL
 * @param {EnhancementScriptOptions} [options] - Options for the enhancement script
 * @returns {Promise<string>} - JavaScript content with configuration and URL embedded
 */
export async function loadEnhancementScript(options = {}) {
	const scriptPath = join(__dirname, 'defaults', 'enhancements.js');
	let script = await readFile(scriptPath, { encoding: 'utf-8' });

	// Replace configuration placeholder
	if (options.configuration) {
		script = script.replace(
			/\/\* __MERMAID_CONFIG__ \*\/ \{[^}]*\}/,
			JSON.stringify(options.configuration)
		);
	}

	// Replace URL placeholder - use provided URL or fall back to bare specifier for importmap resolution
	if (options.url) {
		script = script.replace(
			/\/\* __MERMAID_URL__ \*\/ '[^']*'/,
			`'${options.url}'`
		);
	}

	return script;
}

/**
 * Get script URLs for GitHub Elements
 * @param {import('./configuration.js').GitHubElementsConfiguration} configuration - GitHub Elements configuration
 */
export function getGitHubElementsScriptURLs(configuration) {
	const { enabled = true, elements = [], cdnURL = 'https://esm.sh/@github' } = configuration;

	if (!enabled || elements.length === 0) {
		return [];
	}

	return elements.map(element => `${cdnURL}/${element}-element`);
}
