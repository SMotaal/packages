// @ts-check
/**
 * CLI implementation
 * Uses Node.js 24+ native parseArgs
 */

import { parseArgs } from 'node:util';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { basename, dirname, extname, join, resolve } from 'node:path';
import { glob } from 'node:fs/promises';

import { renderMarkdown } from './renderer.js';
import { assembleDocument, extractTitle } from './assembler.js';
import { resolveConfiguration } from './configuration.js';
import { loadDefaultStyles, loadEnhancementScript, getGitHubElementsScriptURLs } from './styles.js';
import { bundleMermaidAsDataURL, bundleMermaidAsDataURLWithVite, bundleGitHubElements } from './bundler.js';
import { postprocess, processMermaidBlocks, isMermaidCLIAvailable } from './postprocessor.js';
import { inlineImages } from './image-inliner.js';

/**
 * @typedef {object} CLIOptions
 * @property {string[]} files - Input files
 * @property {string} [output] - Output directory
 * @property {string} [configuration] - Configuration file path
 * @property {'auto' | 'light' | 'dark'} [theme] - Color theme
 * @property {string} [context] - GitHub repo context
 * @property {boolean} [singleFile] - Bundle as single file
 * @property {string} [mermaidMode] - Mermaid mode: svg, <version>, latest, or false
 * @property {boolean} [noBundledMermaid] - Use CDN for mermaid instead of bundling
 * @property {'vite' | 'rollup'} [bundler] - Bundler to use (default: vite)
 * @property {boolean} [useRollup] - Use Rollup bundler (shortcut)
 * @property {boolean} [help] - Show help
 * @property {boolean} [version] - Show version
 */

const CLI_OPTIONS = {
	output: {
		type: /** @type {const} */ ('string'),
		short: 'o',
		description: 'Output directory (default: same as input)',
	},
	configuration: {
		type: /** @type {const} */ ('string'),
		short: 'c',
		description: 'Path to configuration file',
	},
	theme: {
		type: /** @type {const} */ ('string'),
		short: 't',
		description: 'Color theme: auto, light, or dark (default: auto)',
	},
	context: {
		type: /** @type {const} */ ('string'),
		description: 'GitHub repo context for relative links (e.g., owner/repo)',
	},
	'single-file': {
		type: /** @type {const} */ ('boolean'),
		short: 's',
		description: 'Bundle all assets into single HTML file',
	},
	'mermaid-mode': {
		type: /** @type {const} */ ('string'),
		short: 'm',
		description: 'Mermaid rendering: svg (server, default), <version> (client), latest, false',
	},
	'no-bundled-mermaid': {
		type: /** @type {const} */ ('boolean'),
		description: 'Use CDN for mermaid instead of bundling (only with -s)',
	},
	bundler: {
		type: /** @type {const} */ ('string'),
		short: 'b',
		description: 'Bundler to use: vite or rollup (default: vite)',
	},
	rollup: {
		type: /** @type {const} */ ('boolean'),
		description: 'Use Rollup bundler (shortcut for --bundler=rollup)',
	},
	help: {
		type: /** @type {const} */ ('boolean'),
		short: 'h',
		description: 'Show this help message',
	},
	version: {
		type: /** @type {const} */ ('boolean'),
		short: 'v',
		description: 'Show version number',
	},
};

/**
 * Parse CLI arguments
 * @param {string[]} args - Command line arguments
 */
export function parseCLI(args) {
	const { values, positionals } = parseArgs({
		args,
		options: CLI_OPTIONS,
		allowPositionals: true,
	});

	return {
		files: positionals,
		output: values.output,
		configuration: values.configuration,
		theme: /** @type {'auto' | 'light' | 'dark' | undefined} */ (values.theme),
		context: values.context,
		singleFile: values['single-file'],
		mermaidMode: values['mermaid-mode'],
		noBundledMermaid: values['no-bundled-mermaid'],
		bundler: /** @type {'vite' | 'rollup' | undefined} */ (values.bundler),
		useRollup: values.rollup,
		help: values.help,
		version: values.version,
	};
}

/**
 * Show help message
 */
export function showHelp() {
	console.log(`
markdown-to-html - Convert Markdown to HTML using GitHub's API

Usage:
  markdown-to-html [options] <files...>

Options:
  -o, --output <dir>     Output directory (default: same as input)
  -c, --configuration <file>  Path to configuration file
  -t, --theme <theme>    Color theme: auto, light, or dark (default: auto)
      --context <repo>   GitHub repo context for relative links (e.g., owner/repo)
  -s, --single-file      Bundle all assets into single HTML file
  -m, --mermaid-mode <mode>  Mermaid rendering mode (default: svg)
                           svg      Server-side SVG (requires @mermaid-js/mermaid-cli)
                           <ver>    Client-side with specific version (e.g., 10.9.0)
                           latest   Client-side with latest CDN version
                           false    Disable mermaid rendering
      --no-bundled-mermaid  Use CDN for mermaid instead of bundling (with -s)
  -b, --bundler <name>   Bundler to use: vite or rollup (default: vite)
      --rollup           Use Rollup bundler (shortcut for -b rollup)
  -h, --help             Show this help message
  -v, --version          Show version number

Examples:
  markdown-to-html README.md
  markdown-to-html --single-file docs/*.md
  markdown-to-html -o dist -t dark src/**/*.md
  markdown-to-html -m latest docs/SPEC.md    # Client-side mermaid
  markdown-to-html -m false README.md        # No mermaid

Environment Variables:
  GITHUB_TOKEN           GitHub API token for higher rate limits
`);
}

/**
 * Show version
 */
export async function showVersion() {
	const pkg = await import('../package.json', { with: { type: 'json' } });
	console.log(pkg.default.version);
}

/**
 * Expand glob patterns in file list
 * @param {string[]} patterns - File patterns
 */
export async function expandGlobs(patterns) {
	const files = [];

	for (const pattern of patterns) {
		if (pattern.includes('*')) {
			// Use Node.js 24+ native glob
			for await (const file of glob(pattern, { cwd: process.cwd() })) {
				if (file.endsWith('.md')) {
					files.push(resolve(file));
				}
			}
		} else {
			files.push(resolve(pattern));
		}
	}

	return [...new Set(files)]; // Deduplicate
}

/**
 * Convert a single Markdown file to HTML
 * @param {string} inputPath - Input file path
 * @param {CLIOptions} options - CLI options
 * @param {import('./configuration.js').Configuration} configuration - Resolved configuration
 */
export async function convertFile(inputPath, options, configuration) {
	// Read input file with explicit UTF-8 encoding
	const markdown = await readFile(inputPath, { encoding: 'utf-8' });

	// Render via GitHub API
	let body = await renderMarkdown(markdown, {
		mode: configuration.github?.mode ?? 'gfm',
		context: configuration.github?.context ?? undefined,
		token: configuration.github?.token,
	});

	// Add heading IDs (GitHub API doesn't include them)
	body = postprocess(body, { headingIds: true });

	// Load styles
	const styles = await loadDefaultStyles(configuration.theme);

	// Determine bundling mode - in single-file mode, bundle everything inline
	const isSingleFile = options.singleFile ?? false;
	const githubElementsEnabled = configuration.githubElements?.enabled ?? false;
	const githubElements = configuration.githubElements?.elements ?? [];

	// Determine mermaid mode (default: svg for server-side rendering)
	const mermaidMode = options.mermaidMode ?? 'svg';
	const mermaidDisabled = mermaidMode === 'false';
	const mermaidServerSide = mermaidMode === 'svg';
	const mermaidEnabled = !mermaidDisabled && (configuration.mermaid?.enabled ?? true);

	const scripts = [];
	/** @type {string[]} */
	let scriptURLs = [];

	// Handle mermaid rendering based on mode
	if (mermaidEnabled) {
		if (mermaidServerSide) {
			// Server-side SVG rendering using @mermaid-js/mermaid-cli
			const cliAvailable = await isMermaidCLIAvailable();
			if (cliAvailable) {
				console.log(`  Rendering mermaid diagrams (server-side SVG)...`);
				body = await processMermaidBlocks(body, {
					theme: configuration.theme === 'dark' ? 'dark' : 'default',
				});
			} else {
				// In SVG mode, do NOT fall back to client-side - leave mermaid blocks as-is
				console.warn(`  Warning: @mermaid-js/mermaid-cli not installed, mermaid diagrams will not be rendered`);
				console.warn(`  Install with: npm install -D @mermaid-js/mermaid-cli puppeteer`);
				console.warn(`  Or use --mermaid-mode=latest for client-side rendering`);
			}
		} else {
			// Client-side rendering with specified version or CDN
			let mermaidURL = configuration.mermaid?.cdnURL ?? '';

			// Handle version-specific mermaid URL
			if (mermaidMode !== 'latest' && /^\d/.test(mermaidMode)) {
				// Specific version requested (e.g., "10.9.0")
				mermaidURL = `https://cdn.jsdelivr.net/npm/mermaid@${mermaidMode}/dist/mermaid.min.js`;
			}

			if (isSingleFile && !options.noBundledMermaid) {
				// Determine which bundler to use (--rollup flag takes precedence over --bundler)
				const useRollup = options.useRollup || options.bundler === 'rollup';
				const bundlerName = useRollup ? 'Rollup' : 'Vite';

				console.log(`  Bundling mermaid (${bundlerName})...`);

				// Use appropriate bundler
				mermaidURL = useRollup
					? await bundleMermaidAsDataURL()
					: await bundleMermaidAsDataURLWithVite();
			}

			const enhancementScript = await loadEnhancementScript({
				configuration: configuration.mermaid?.configuration,
				url: mermaidURL,
			});
			scripts.push(enhancementScript);
		}
	}

	// Bundle GitHub elements when in single-file mode, otherwise use CDN URLs
	if (githubElementsEnabled && githubElements.length > 0) {
		if (isSingleFile) {
			// Bundle GitHub elements inline
			console.log(`  Bundling GitHub elements (${githubElements.join(', ')})...`);
			const bundledElements = await bundleGitHubElements(githubElements);
			if (bundledElements) {
				scripts.push(bundledElements);
			}
		} else if (configuration.githubElements) {
			// Use CDN URLs for external loading
			scriptURLs = getGitHubElementsScriptURLs(configuration.githubElements);
		}
	}

	// Assemble document
	let html = assembleDocument(body, {
		title: extractTitle(body) ?? undefined,
		theme: configuration.theme,
		styles,
		scripts,
		scriptURLs,
		singleFile: isSingleFile,
	});

	// Determine output path
	const inputDir = dirname(inputPath);
	const outputDir = options.output ? resolve(options.output) : inputDir;
	const outputName = basename(inputPath, extname(inputPath)) + '.html';
	const outputPath = join(outputDir, outputName);

	// Inline images when in single-file mode
	if (isSingleFile) {
		console.log(`  Inlining images...`);
		html = await inlineImages(html, { basePath: inputDir });
	}

	// Ensure output directory exists
	await mkdir(outputDir, { recursive: true });

	// Write output with explicit UTF-8 encoding
	await writeFile(outputPath, html, { encoding: 'utf-8' });

	return outputPath;
}

/**
 * Main CLI entry point
 * @param {string[]} args - Command line arguments
 */
export async function main(args) {
	try {
		const options = parseCLI(args);

		if (options.help) {
			showHelp();
			return 0;
		}

		if (options.version) {
			await showVersion();
			return 0;
		}

		if (options.files.length === 0) {
			console.error('Error: No input files specified');
			showHelp();
			return 1;
		}

		// Expand glob patterns
		const files = await expandGlobs(options.files);

		if (files.length === 0) {
			console.error('Error: No matching files found');
			return 1;
		}

		// Resolve configuration (use first file's directory)
		const firstFile = /** @type {string} */ (files[0]);
		const inputDir = dirname(firstFile);
		const configuration = await resolveConfiguration({
			configuration: options.configuration,
			theme: options.theme,
			context: options.context,
		}, inputDir);

		// Convert each file
		for (const file of files) {
			try {
				const outputPath = await convertFile(file, options, configuration);
				console.log(`✓ ${file} → ${outputPath}`);
			} catch (error) {
				const message = error instanceof Error ? error.message : String(error);
				console.error(`✗ ${file}: ${message}`);
				// Continue with other files but track failure
			}
		}

		return 0;
	} catch (error) {
		const message = error instanceof Error ? error.message : String(error);
		console.error(`Error: ${message}`);
		return 1;
	}
}
