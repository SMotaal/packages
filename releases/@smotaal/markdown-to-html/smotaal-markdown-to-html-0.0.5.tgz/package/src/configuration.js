// @ts-check
/**
 * Configuration loader
 * Loads and merges configuration from files and CLI options
 */

import { readFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

/**
 * @typedef {object} GitHubConfiguration
 * @property {string} [token] - GitHub API token
 * @property {'gfm' | 'markdown'} [mode='gfm'] - Rendering mode
 * @property {string | null} [context=null] - Repository context
 */

/**
 * @typedef {object} MermaidConfiguration
 * @property {boolean} [enabled=true] - Enable mermaid rendering
 * @property {string} [cdnURL] - CDN URL for mermaid library
 * @property {object} [configuration] - Mermaid.initialize() options
 * @property {string} [selector] - Selector for mermaid code blocks
 */

/**
 * @typedef {object} GitHubElementsConfiguration
 * @property {boolean} [enabled=true] - Enable GitHub elements
 * @property {string[]} [elements] - Elements to include
 * @property {string} [cdnURL] - CDN base URL
 */

/**
 * @typedef {object} PrintConfiguration
 * @property {boolean} [enabled=true] - Enable print optimization
 * @property {string[]} [avoidBreakInside] - Elements to avoid breaking inside
 * @property {string[]} [avoidBreakAfter] - Elements to avoid breaking after
 */

/**
 * @typedef {object} BundleConfiguration
 * @property {boolean} [inlineAssets=true] - Inline all external resources
 * @property {boolean} [minify=false] - Minify output
 */

/**
 * @typedef {object} Configuration
 * @property {GitHubConfiguration} [github] - GitHub API settings
 * @property {'auto' | 'light' | 'dark'} [theme='auto'] - Color theme
 * @property {MermaidConfiguration} [mermaid] - Mermaid configuration
 * @property {GitHubElementsConfiguration} [githubElements] - GitHub elements configuration
 * @property {PrintConfiguration} [print] - Print optimization configuration
 * @property {BundleConfiguration} [bundle] - Bundle configuration
 */

/** @type {Configuration} */
export const defaultConfiguration = {
	github: {
		token: process.env.GITHUB_TOKEN,
		mode: 'gfm',
		context: null,
	},
	theme: 'auto',
	mermaid: {
		enabled: true,
		// Use jsdelivr UMD build - self-contained with no external imports
		// ESM builds have chunked imports that fail when served through Vite or as data: URLs
		cdnURL: 'https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js',
		configuration: { startOnLoad: true },
		selector: 'pre > code.language-mermaid',
	},
	githubElements: {
		enabled: true,
		elements: ['clipboard-copy', 'relative-time'],
		cdnURL: 'https://esm.sh/@github',
	},
	print: {
		enabled: true,
		avoidBreakInside: ['table', 'figure', 'div.no-break', 'pre'],
		avoidBreakAfter: ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'],
	},
	bundle: {
		inlineAssets: true,
		minify: false,
	},
};

/**
 * Load configuration from a file
 * @param {string} configurationPath - Path to configuration file
 * @returns {Promise<Partial<Configuration>>} - Loaded configuration
 */
export async function loadConfigurationFile(configurationPath) {
	const absolutePath = resolve(configurationPath);
	const fileURL = pathToFileURL(absolutePath).href;

	try {
		const module = await import(fileURL);
		return module.default ?? module;
	} catch (error) {
		if (error.code === 'ERR_MODULE_NOT_FOUND') {
			return {};
		}
		throw error;
	}
}

/**
 * Find configuration file
 * @param {string} inputDir - Directory of input file
 * @param {string} [workspaceRoot] - Workspace root directory
 * @returns {Promise<string | null>} - Path to configuration file or null
 */
export async function findConfigurationFile(inputDir, workspaceRoot = process.cwd()) {
	const configurationNames = [
		'markdown-to-html.config.js',
		'markdown-to-html.config.mjs',
	];

	// Check input directory first
	for (const name of configurationNames) {
		const configurationPath = join(inputDir, name);
		try {
			await readFile(configurationPath);
			return configurationPath;
		} catch {
			// File doesn't exist, continue
		}
	}

	// Check workspace root
	for (const name of configurationNames) {
		const configurationPath = join(workspaceRoot, name);
		try {
			await readFile(configurationPath);
			return configurationPath;
		} catch {
			// File doesn't exist, continue
		}
	}

	return null;
}

/**
 * Merge configurations (deep merge)
 * @param {Configuration} base - Base configuration
 * @param {Partial<Configuration>} override - Override configuration
 * @returns {Configuration} - Merged configuration
 */
export function mergeConfiguration(base, override) {
	const result = { ...base };

	for (const key of Object.keys(override)) {
		const value = override[key];
		if (value !== undefined && value !== null) {
			if (typeof value === 'object' && !Array.isArray(value) && base[key]) {
				result[key] = { ...base[key], ...value };
			} else {
				result[key] = value;
			}
		}
	}

	return result;
}

/**
 * @typedef {object} ImportMapOptions
 * @property {string} [mermaidURL] - Override mermaid URL (e.g., data: URL for bundling)
 */

/**
 * Generate import map for standalone HTML (bare specifier resolution)
 * Maps package names to CDN URLs so `import('mermaid')` works without bundler
 * @param {Configuration} configuration - Configuration
 * @param {ImportMapOptions} [options] - Import map options
 * @returns {Record<string, string>} - Import map entries
 */
export function generateImportMap(configuration, options = {}) {
	/** @type {Record<string, string>} */
	const imports = {};

	// Mermaid: bare specifier → CDN URL or bundled data: URL
	if (configuration.mermaid?.enabled) {
		const mermaidURL = options.mermaidURL ?? configuration.mermaid?.cdnURL;
		if (mermaidURL) {
			imports['mermaid'] = mermaidURL;
		}
	}

	return imports;
}

/**
 * Resolve configuration from CLI options and configuration file
 * @param {object} cliOptions - CLI options
 * @param {string} inputDir - Directory of input file
 * @returns {Promise<Configuration>} - Resolved configuration
 */
export async function resolveConfiguration(cliOptions, inputDir) {
	let configuration = { ...defaultConfiguration };

	// Load configuration file if specified or found
	const configurationPath = cliOptions.configuration ?? await findConfigurationFile(inputDir);
	if (configurationPath) {
		const fileConfiguration = await loadConfigurationFile(configurationPath);
		configuration = mergeConfiguration(configuration, fileConfiguration);
	}

	// Apply CLI overrides
	if (cliOptions.theme) {
		configuration.theme = cliOptions.theme;
	}
	if (cliOptions.context) {
		configuration.github = { ...configuration.github, context: cliOptions.context };
	}

	return configuration;
}
