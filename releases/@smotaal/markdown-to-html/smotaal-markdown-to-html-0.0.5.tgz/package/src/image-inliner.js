// @ts-check
/**
 * Image Inliner
 * Inlines external image references as data URLs for single-file output
 */

import { readFile } from 'node:fs/promises';
import { dirname, join, resolve, extname } from 'node:path';

/**
 * MIME types for common image formats
 * @type {Record<string, string>}
 */
const MIME_TYPES = {
	'.svg': 'image/svg+xml',
	'.png': 'image/png',
	'.jpg': 'image/jpeg',
	'.jpeg': 'image/jpeg',
	'.gif': 'image/gif',
	'.webp': 'image/webp',
	'.ico': 'image/x-icon',
	'.avif': 'image/avif',
};

/**
 * Get MIME type for an image file extension
 * @param {string} ext - File extension (with dot)
 * @returns {string | null} - MIME type or null if not an image
 */
export function getMimeType(ext) {
	return MIME_TYPES[ext.toLowerCase()] ?? null;
}

/**
 * Convert an image file to a data URL
 * @param {string} imagePath - Absolute path to the image file
 * @returns {Promise<string>} - Data URL
 */
export async function imageToDataURL(imagePath) {
	const ext = extname(imagePath);
	const mimeType = getMimeType(ext);

	if (!mimeType) {
		throw new Error(`Unsupported image format: ${ext}`);
	}

	const buffer = await readFile(imagePath);

	// For SVG, we can use UTF-8 encoding for smaller size
	if (ext.toLowerCase() === '.svg') {
		const svgContent = buffer.toString('utf-8');
		// URL-encode special characters for data URI
		const encoded = encodeURIComponent(svgContent)
			.replace(/'/g, '%27')
			.replace(/"/g, '%22');
		return `data:${mimeType};charset=utf-8,${encoded}`;
	}

	// For binary formats, use base64
	const base64 = buffer.toString('base64');
	return `data:${mimeType};base64,${base64}`;
}

/**
 * @typedef {object} InlineImagesOptions
 * @property {string} basePath - Base path for resolving relative image URLs
 * @property {boolean} [silent=false] - Suppress warnings for missing images
 */

/**
 * Inline all image references in HTML as data URLs
 * @param {string} html - HTML content with image references
 * @param {InlineImagesOptions} options - Options for inlining
 * @returns {Promise<string>} - HTML with images inlined as data URLs
 */
export async function inlineImages(html, options) {
	const { basePath, silent = false } = options;

	// Match img tags with src attributes (both single and double quotes)
	const imgPattern = /<img([^>]*)\ssrc=["']([^"']+)["']([^>]*)>/gi;

	// Also match anchor tags wrapping images (common pattern for clickable images)
	const anchorPattern = /<a([^>]*)\shref=["']([^"']+)["']([^>]*)>/gi;

	// Collect all unique image URLs that need inlining
	/** @type {Map<string, string>} */
	const urlToDataURL = new Map();

	// Find all image src URLs
	let match;
	while ((match = imgPattern.exec(html)) !== null) {
		const src = match[2];
		if (src && !src.startsWith('data:') && !src.startsWith('http://') && !src.startsWith('https://')) {
			urlToDataURL.set(src, '');
		}
	}

	// Also find anchor hrefs that point to images
	while ((match = anchorPattern.exec(html)) !== null) {
		const href = match[2];
		if (href) {
			const ext = extname(href).toLowerCase();
			if (getMimeType(ext) && !href.startsWith('data:') && !href.startsWith('http://') && !href.startsWith('https://')) {
				urlToDataURL.set(href, '');
			}
		}
	}

	// Convert each image to data URL
	for (const url of urlToDataURL.keys()) {
		try {
			// Resolve the image path relative to basePath
			const imagePath = resolve(basePath, url);
			const dataURL = await imageToDataURL(imagePath);
			urlToDataURL.set(url, dataURL);
		} catch (error) {
			if (!silent) {
				const message = error instanceof Error ? error.message : String(error);
				console.warn(`[image-inliner] Could not inline ${url}: ${message}`);
			}
			// Keep original URL if inlining fails
		}
	}

	// Replace all occurrences in the HTML
	let result = html;
	for (const [url, dataURL] of urlToDataURL) {
		if (dataURL) {
			// Escape special regex characters in URL
			const escapedURL = url.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
			// Replace in both src and href attributes
			result = result.replace(new RegExp(`(src|href)=["']${escapedURL}["']`, 'g'), `$1="${dataURL}"`);
		}
	}

	return result;
}
