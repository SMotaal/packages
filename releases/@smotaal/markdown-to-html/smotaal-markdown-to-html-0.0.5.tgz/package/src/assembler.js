// @ts-check
/**
 * HTML Assembler
 * Wraps rendered Markdown body in a complete HTML document
 */

/**
 * @typedef {Record<string, string>} ImportMap
 */

/**
 * @typedef {object} AssemblerOptions
 * @property {string} [title] - Document title (extracted from H1 if not provided)
 * @property {string} [lang='en'] - Document language
 * @property {string} [charset='utf-8'] - Document charset
 * @property {'auto' | 'light' | 'dark'} [theme='auto'] - Color scheme theme
 * @property {string[]} [styles=[]] - CSS content to embed
 * @property {string[]} [scripts=[]] - JavaScript content to embed
 * @property {string[]} [scriptURLs=[]] - Script URLs to include
 * @property {ImportMap} [importMap] - Import map for bare specifier resolution
 * @property {boolean} [singleFile=false] - Whether this is a single-file output
 */

/**
 * Extract title from rendered HTML (first H1)
 * @param {string} html - Rendered HTML content
 * @returns {string | null} - Extracted title or null
 */
export function extractTitle(html) {
	const match = html.match(/<h1[^>]*>([^<]+)<\/h1>/i);
	return match ? match[1].trim() : null;
}

/**
 * Assemble a complete HTML document
 * @param {string} body - Rendered Markdown HTML
 * @param {AssemblerOptions} [options={}] - Assembly options
 * @returns {string} - Complete HTML document
 */
export function assembleDocument(body, options = {}) {
	const {
		title = extractTitle(body) ?? 'Document',
		lang = 'en',
		charset = 'utf-8',
		theme = 'auto',
		styles = [],
		scripts = [],
		scriptURLs = [],
		importMap,
		singleFile = false,
	} = options;

	const themeClass = theme === 'auto' ? '' : ` data-color-mode="${theme}"`;

	const styleBlocks = styles.map(css => `<style>\n${css}\n</style>`).join('\n');

	// Import map must appear before any module scripts for resolution to work
	const importMapBlock = importMap && Object.keys(importMap).length > 0
		? `<script type="importmap">\n${JSON.stringify({ imports: importMap }, null, '\t')}\n</script>`
		: '';

	const scriptBlocks = scripts.map(js => `<script type="module">\n${js}\n</script>`).join('\n');

	const scriptURLBlocks = scriptURLs
		.map(url => `<script type="module" src="${url}"></script>`)
		.join('\n');

	return `<!DOCTYPE html>
<html lang="${lang}"${themeClass}>
<head>
<meta charset="${charset}">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escapeHTML(title)}</title>
${styleBlocks}
</head>
<body>
<article class="markdown-body">
${body}
</article>
${importMapBlock}
${scriptURLBlocks}
${scriptBlocks}
</body>
</html>
`;
}

/**
 * Escape HTML special characters
 * @param {string} str - String to escape
 * @returns {string} - Escaped string
 */
function escapeHTML(str) {
	return str
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;')
		.replace(/'/g, '&#039;');
}
