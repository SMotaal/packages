// @ts-check
/**
 * Asset bundler with both Rollup and Vite implementations
 * Bundles mermaid and GitHub elements into self-contained ESM modules for inlining
 *
 * Note: Mermaid does not support tree-shaking. The bundle size difference between
 * Rollup (2.48MB) and Vite (3.48MB) is due to bundler implementation differences,
 * not tree-shaking. Both include the full mermaid library.
 */

import { rollup } from 'rollup';
import { nodeResolve } from '@rollup/plugin-node-resolve';
import commonjs from '@rollup/plugin-commonjs';
import terser from '@rollup/plugin-terser';
import { build } from 'vite';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { writeFile, mkdir, rm, readFile } from 'node:fs/promises';

const __dirname = dirname(fileURLToPath(import.meta.url));

/**
 * Bundle a module using Rollup into a self-contained ESM
 * Uses terser with dead_code elimination for tree-shaking
 * @param {string} entryCode - Entry point code
 * @param {string} name - Bundle name (for temp files)
 * @returns {Promise<string>} - Bundled ESM code
 */
async function bundleWithRollup(entryCode, name) {
	const tempDir = join(__dirname, '../.temp-bundle');
	const entryPath = join(tempDir, `${name}-entry.js`);

	try {
		await mkdir(tempDir, { recursive: true });
		await writeFile(entryPath, entryCode, 'utf-8');

		// Bundle with Rollup using the Google AI recommended configuration
		const bundle = await rollup({
			input: entryPath,
			plugins: [
				nodeResolve(),
				commonjs(),
				// Terser is critical: it removes the "dead" diagram code that
				// isn't explicitly registered in the entry
				terser({
					compress: {
						dead_code: true,
						passes: 2
					}
				})
			],
			// Treat all diagram-related side effects as potentially removable
			treeshake: {
				moduleSideEffects: 'no-external',
				propertyReadSideEffects: false,
			},
			// Suppress circular dependency warnings from d3, chevrotain, langium
			onLog(level, log, handler) {
				if (log.code === 'CIRCULAR_DEPENDENCY') return;
				handler(level, log);
			},
		});

		// Generate the bundle as ESM
		const { output } = await bundle.generate({
			format: 'es',
			inlineDynamicImports: true,
		});

		await bundle.close();

		// Return the bundled code
		return output[0].code;
	} finally {
		// Clean up temp directory
		await rm(tempDir, { recursive: true, force: true }).catch(() => {});
	}
}

/**
 * Bundle a module using Vite with Rollup plugins into a self-contained ESM
 * Uses the same terser configuration as bundleWithRollup for comparison
 * @param {string} entryCode - Entry point code
 * @param {string} name - Bundle name (for temp files)
 * @returns {Promise<string>} - Bundled ESM code
 */
async function bundleWithVite(entryCode, name) {
	const tempDir = join(__dirname, '../.temp-bundle-vite');
	const entryPath = join(tempDir, `${name}-entry.js`);
	const outDir = join(tempDir, 'dist');

	try {
		await mkdir(tempDir, { recursive: true });
		await writeFile(entryPath, entryCode, 'utf-8');

		// Bundle with Vite using the same Rollup terser plugin
		await build({
			root: tempDir,
			logLevel: 'silent',
			build: {
				lib: {
					entry: entryPath,
					formats: ['es'],
					fileName: name,
				},
				outDir,
				emptyOutDir: true,
				// Use terser via Rollup plugin for same dead_code elimination
				minify: false, // Disable esbuild minification
				rollupOptions: {
					output: {
						inlineDynamicImports: true,
					},
					plugins: [
						// Terser with same config as Rollup bundler
						terser({
							compress: {
								dead_code: true,
								passes: 2
							}
						})
					],
					treeshake: {
						moduleSideEffects: 'no-external',
						propertyReadSideEffects: false,
					},
					onLog(level, log, handler) {
						if (log.code === 'CIRCULAR_DEPENDENCY') return;
						handler(level, log);
					},
				},
			},
			resolve: {
				dedupe: ['mermaid', '@github/clipboard-copy-element', '@github/relative-time-element'],
			},
		});

		// Read the bundled output
		const bundledPath = join(outDir, `${name}.js`);
		return await readFile(bundledPath, 'utf-8');
	} finally {
		// Clean up temp directory
		await rm(tempDir, { recursive: true, force: true }).catch(() => {});
	}
}

/**
 * Bundle mermaid into a self-contained ESM module using Rollup
 *
 * @returns {Promise<string>} - Bundled ESM code
 */
export async function bundleMermaid() {
	const entryCode = `
/**
 * Mermaid bundle (Rollup)
 */
import mermaid from 'mermaid';
export default mermaid;
`;

	return bundleWithRollup(entryCode, 'mermaid');
}

/**
 * Bundle mermaid into a self-contained ESM module using Vite
 *
 * @returns {Promise<string>} - Bundled ESM code
 */
export async function bundleMermaidWithVite() {
	const entryCode = `
/**
 * Mermaid bundle (Vite)
 */
import mermaid from 'mermaid';
export default mermaid;
`;

	return bundleWithVite(entryCode, 'mermaid');
}

/**
 * Bundle GitHub elements into a self-contained ESM module
 * @param {string[]} elements - Element names to bundle (e.g., ['clipboard-copy', 'relative-time'])
 * @returns {Promise<string>} - Bundled ESM code
 */
export async function bundleGitHubElements(elements) {
	if (elements.length === 0) {
		return '';
	}

	// Map element names to package imports
	const imports = elements.map(el => {
		const packageName = `@github/${el}-element`;
		return `import '${packageName}';`;
	}).join('\n');

	const entryCode = `
// Import GitHub elements for bundling (self-registering)
${imports}
`;
	return bundleWithRollup(entryCode, 'github-elements');
}

/**
 * Bundle mermaid and return as a data: URL (using Rollup)
 * @returns {Promise<string>} - Data URL containing the bundled module
 */
export async function bundleMermaidAsDataURL() {
	const bundledCode = await bundleMermaid();
	const base64 = Buffer.from(bundledCode).toString('base64');
	return `data:text/javascript;base64,${base64}`;
}

/**
 * Bundle mermaid and return as a data: URL (using Vite)
 * @returns {Promise<string>} - Data URL containing the bundled module
 */
export async function bundleMermaidAsDataURLWithVite() {
	const bundledCode = await bundleMermaidWithVite();
	const base64 = Buffer.from(bundledCode).toString('base64');
	return `data:text/javascript;base64,${base64}`;
}
